package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TieredDtlNullCheck implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> tieredDetails = MVEL.eval("loan_account.?tiered_details", context, List.class);
		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		if (tieredDetails != null) {
			Iterator<Map<?, ?>> itr = tieredDetails.iterator();
			while (itr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) itr.next();
				BigDecimal anchorRate = new BigDecimal(0);
				BigDecimal netMarkUp = new BigDecimal(0);
				BigDecimal interestRate = new BigDecimal(0);
				BigDecimal tieredId=new BigDecimal(0);
				for(Map.Entry entries:mapValues.entrySet()){
					if("ID".equals(entries.getKey()))
						tieredId=(BigDecimal)entries.getValue();
					if("NET_MARKUP".equals(entries.getKey()))
						netMarkUp=(BigDecimal)entries.getValue();
					if("ANCHOR_RATE".equals(entries.getKey()))
						anchorRate=(BigDecimal)entries.getValue();
					if("INTEREST_RATE".equals(entries.getKey()))
						interestRate=(BigDecimal)entries.getValue();
						
				}
				if(interestRate==null||netMarkUp==null||anchorRate==null){
					logList.add("AnchorRate or InterestRate or NetMarkup is Null in Tiered Details for Tiered Id:"+tieredId);
					resultFlag=false;
				}
				
			}
			
		}
		else{
			logList.add("No data available in Tiered Details");
			resultFlag=false;
		}
		if(resultFlag)
			logList.add("AnchorRate or InterestRate or NetMarkup is not Null in Tiered Details");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
