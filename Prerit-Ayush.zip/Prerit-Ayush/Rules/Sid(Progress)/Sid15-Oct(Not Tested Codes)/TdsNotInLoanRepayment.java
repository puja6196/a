package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TdsNotInLoanRepayment implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> tdsDetails = MVEL.eval("loan_account.?tds_details", context, List.class);
		List<Map<?, ?>> loanRepayment = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		boolean resultFlag=true;
		List<String>logList=new ArrayList<>();
		if(tdsDetails!=null&&loanRepayment==null){
			Iterator<Map<?,?>>itrTds=tdsDetails.iterator();
			List<BigDecimal> tdsList=new ArrayList<>();
			while(itrTds.hasNext()){
				Map<String,String> mapValues=(Map<String,String>)itrTds.next();
				BigDecimal tdsLoanId=new BigDecimal(0);
				
				for(Map.Entry entries:mapValues.entrySet()){
					if("LOANID".equals(entries.getKey()))
						tdsLoanId=(BigDecimal)entries.getValue();
				}
				tdsList.add(tdsLoanId);
			}
			Iterator<Map<?,?>>itrRepayment=loanRepayment.iterator();
				while(itrRepayment!=null){
					Map<String,String> mapValues=(Map<String,String>)itrRepayment.next();
					BigDecimal repaymentLoanId=new BigDecimal(0);
					BigDecimal tdsAmount=new BigDecimal(0);
					BigDecimal tdsRate=new BigDecimal(0);
					BigDecimal repaymentId=new BigDecimal(0);
					for(Map.Entry entries:mapValues.entrySet()){
						if("LOANID".equals(entries.getKey()))
							repaymentLoanId=(BigDecimal)entries.getValue();
						if("tds_amt".equals(entries.getKey()))
							tdsAmount=(BigDecimal)entries.getValue();
						if("tds_rate".equals(entries.getKey()))
							tdsRate=(BigDecimal)entries.getValue();
						if("ID".equals(entries.getKey()))
							repaymentId=(BigDecimal)entries.getValue();
					}
					if((tdsList.contains(repaymentLoanId))&&(tdsAmount!=null)&&(tdsRate!=null)){
						//do nothing
					}
					else{
						logList.add("Tds Details not available in Loan Repayment for Repayment ID:"+repaymentId);
						resultFlag=false;
					}
				}
			}
		else{
			logList.add("No data Available in Loan Repayment and Tds Details");
			resultFlag=false;
		}
		if(resultFlag)
			logList.add("Tds Details is available in Loan Repayment");
		logger.setLog(logList);
		return resultFlag;
	}
	

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
