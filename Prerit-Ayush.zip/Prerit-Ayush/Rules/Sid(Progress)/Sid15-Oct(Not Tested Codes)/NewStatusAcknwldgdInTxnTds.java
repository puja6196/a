package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class NewStatusAcknwldgdInTxnTds implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> tdsTxnDetails = MVEL.eval("loan_account.?tds_details", context, List.class);
		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		if (tdsTxnDetails != null) {
			Iterator<Map<?, ?>> itr = tdsTxnDetails.iterator();
			while (itr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) itr.next();
				BigDecimal txnId = new BigDecimal(0);
				BigDecimal newStatus = new BigDecimal(0);
				BigDecimal status515120 = new BigDecimal(0);
				BigDecimal certificateNumber = new BigDecimal(0);
				Date certificateDate = null;
				for (Map.Entry entries : mapValues.entrySet()) {
					if ("NEW_STATUS".equals(entries.getKey()))
						newStatus = (BigDecimal) entries.getValue();
					if ("CERTIFICATE_DATE".equals(entries.getKey()))
						certificateDate = (Date) entries.getValue();
					if ("ID".equals(entries.getKey()))
						txnId = (BigDecimal) entries.getValue();
					if ("CERTIFICATE_NUMBER".equals(entries.getKey()))
						certificateNumber = (BigDecimal) entries.getValue();
				}
				if ((newStatus.compareTo(status515120) == 0)
						&& (certificateDate == null || certificateNumber == null)) {
					logList.add(
							"Tds Txn Details where Certificate Date or Certificate Number is Null with Current Status Acknowledged for Txn ID:"
									+ txnId);
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data available in Tds Txn Details");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add(
					"Tds Txn Details where Certificate Date or Certificate Number is not Null with Current Status except Acknowledged");

		logger.setLog(logList);
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		return true;
	}

}
