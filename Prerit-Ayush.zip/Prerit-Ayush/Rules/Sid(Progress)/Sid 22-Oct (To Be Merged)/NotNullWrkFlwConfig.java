package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class NotNullWrkFlwConfig implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		boolean resultFlag = true;
		String workFlowConfig = null;
		BigDecimal workFlowId = new BigDecimal(0);
		List<String> logList = new ArrayList<>();
		List<Map<?, ?>> loanTaskMapDtls = MVEL.eval("loan_account.?cas_loan_app_details.?loan_task_map_details",
				context, List.class);
		if (loanTaskMapDtls != null) {
			Iterator<Map<?, ?>> it = loanTaskMapDtls.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("WORKFLOW_CONFIGURATION").equals(entries.getKey()))
						workFlowConfig = entries.getValue().toString();
					if (("ID").equals(entries.getKey()))
						workFlowId = (BigDecimal) entries.getValue();
				}
				if (workFlowConfig.length() <= 65) {
					logList.add("Work Flow Config type is Null for Id :" + workFlowId);
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data available in Loan Task Map Details");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add("Work Flow Config type is not Null");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		return true;
	}

}
