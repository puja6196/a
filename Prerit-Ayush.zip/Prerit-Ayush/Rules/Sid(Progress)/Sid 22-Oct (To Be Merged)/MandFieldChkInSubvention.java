package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class MandFieldChkInSubvention implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> subvetionDetails = MVEL.eval("loan_account.?subvention_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		String loanAcctStatus=null;
		try{
		loanAcctStatus = (String) ctx
				.getValue("loan_account/STATUS", String.class);
		}
		
		catch(Exception e){
			logList.add("Exception occured while Retrieving data from Loan Account Details ");
		}

		if(subvetionDetails!=null){
			Iterator<Map<?,?>>subventionItr=subvetionDetails.iterator();
			while(subventionItr.hasNext()){
				Map<String, String> mapValues = (Map<String, String>) subventionItr.next();
				BigDecimal subventionLoanId = new BigDecimal(0);
				BigDecimal subventionId = new BigDecimal(0);
				String subventionLoanAcctNo=null;
				for (Map.Entry entries : mapValues.entrySet()) {
					try{
						if ("LOANID".equals(entries.getKey()))
							subventionLoanId = (BigDecimal) entries.getValue();
						if ("ID".equals(entries.getKey()))
							subventionId = (BigDecimal) entries.getValue();
						if ("LOAN_ACCOUNT_NO".equals(entries.getKey()))
							subventionLoanAcctNo = (String) entries.getValue();
					}
					catch(Exception e){
						logList.add("Exception occured while Retrieving data from Subvention Details");
					}
				}
				if((subventionLoanAcctNo==null||subventionLoanId==null)&&("A".equals(loanAcctStatus))){
					logList.add("Mandatory Fields in Subvention Details are Missing for Subvention id"+subventionId);
					resultFlag=false;
					
				}
			}
		}
		else{
			logList.add("No data available in Subvention Details");
			resultFlag=false;
		}
		
		if(resultFlag)
			logList.add("Mandatory Fields in Subvention Details are available");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		return true;
	}

}
