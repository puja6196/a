package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class MandFieldChkInKnockOffHdr implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> knockOffhdr = MVEL.eval("loan_account.?knockoff_hdr_details", context, List.class);
		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		if (knockOffhdr != null) {
			Iterator<Map<?, ?>> itr = knockOffhdr.iterator();
			while (itr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) itr.next();
				BigDecimal currencyMstId = new BigDecimal(0);
				BigDecimal knockOffAmt = new BigDecimal(0);
				BigDecimal knockOffChannel = new BigDecimal(0);
				Date knockOffTxnDate = null;
				String reversalFlag = null;
				String mcStatus = null;
				BigDecimal knockOffId = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if ("ID".equals(entries.getKey()))
						knockOffId = (BigDecimal) entries.getValue();
					if ("CURRENCY_MST_ID".equals(entries.getKey()))
						currencyMstId = (BigDecimal) entries.getValue();
					if ("KNOCKOFF_AMOUNT".equals(entries.getKey()))
						knockOffAmt = (BigDecimal) entries.getValue();
					if ("KNOCKOFF_CHANNEL".equals(entries.getKey()))
						knockOffChannel = (BigDecimal) entries.getValue();
					if ("KNOCKOFF_TXN_DATE".equals(entries.getKey()))
						knockOffTxnDate = (Date) entries.getValue();
					if ("KNOCKOFF_REVERSAL_FLAG".equals(entries.getKey()))
						reversalFlag = (String) entries.getValue();
					if ("MC_STATUS".equals(entries.getKey()))
						mcStatus = (String) entries.getValue();

				}
				if (knockOffId == null || knockOffAmt == null || knockOffChannel == null || currencyMstId == null
						|| knockOffTxnDate == null || reversalFlag == null || mcStatus == null) {
					logList.add("Mandatory Fields in KnockOff Header Details are Missing");
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data Available in KnockOff Header");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add("Mandatory Fields in KnockOff Header Details are not Missing");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
