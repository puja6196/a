package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;


public class SbvntnEndDteNtEqlsMaxSbvtnEndDte implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> subvetionTxnDetails = MVEL.eval("loan_account.?subvention_txn_details",
				context, List.class);
		List<Map<?, ?>> subvetionDetails = MVEL.eval("loan_account.?subvention_details", context, List.class);
		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		if (subvetionDetails != null && subvetionTxnDetails != null) {
			Iterator<Map<?, ?>> subvetionItr = subvetionDetails.iterator();
			List<BigDecimal> subventionLoanIdList = new ArrayList<>();
			List<BigDecimal> subventionIdList = new ArrayList<>();
			List<Date> subventionEndDateList = new ArrayList<>();
			while (subvetionItr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) subvetionItr.next();
				BigDecimal subventionLoanId = new BigDecimal(0);
				BigDecimal subventionId = new BigDecimal(0);
				Date subventionEndDate = null;
				for (Map.Entry entries : mapValues.entrySet()) {
					if ("LOANID".equals(entries.getKey()))
						subventionLoanId = (BigDecimal) entries.getValue();
					if ("ID".equals(entries.getKey()))
						subventionId = (BigDecimal) entries.getValue();
					if ("SUBVENTION_END_DATE".equals(entries.getKey()))
						subventionEndDate = (Date) entries.getValue();
				}
				subventionIdList.add(subventionId);
				subventionLoanIdList.add(subventionLoanId);
				subventionEndDateList.add(subventionEndDate);
			}
			Iterator<Map<?, ?>> subvetionTxnItr = subvetionTxnDetails.iterator();
			List<Date> txnMaxEndDateList = new ArrayList<>();
			while (subvetionTxnItr.hasNext()) {
				Map<String, String> mapValue = (Map<String, String>) subvetionTxnItr.next();
				BigDecimal subventionTxnLoanId = new BigDecimal(0);
				BigDecimal txnSubvetionId = new BigDecimal(0);
				BigDecimal txnId = new BigDecimal(0);
				Date subventionEndMaxDate = null;
				Date subventionTxnEndDate = null;
				String txnMcStatus = null;
				for (Map.Entry entries : mapValue.entrySet()) {
					if ("LOANID".equals(entries.getKey()))
						subventionTxnLoanId = (BigDecimal) entries.getValue();
					if ("SUBVENTION_ID".equals(entries.getKey()))
						txnSubvetionId = (BigDecimal) entries.getValue();
					if ("ID".equals(entries.getKey()))
						txnId = (BigDecimal) entries.getValue();
					if ("SUBVENTION_END_DATE".equals(entries.getKey()))
						subventionTxnEndDate = (Date) entries.getValue();
					if ("MC_STATUS".equals(entries.getKey()))
						txnMcStatus = (String) entries.getValue();
				}
				txnMaxEndDateList.add(subventionTxnEndDate);
				subventionEndMaxDate = Collections.max(txnMaxEndDateList);
				if ((subventionIdList.contains(txnSubvetionId)) && (subventionLoanIdList.contains(subventionTxnLoanId))
						&& (!(subventionEndDateList.contains(subventionEndMaxDate))) && ("A".equals(txnMcStatus))) {
					logList.add(
							"Subvention End Date in Subvention Details is not equal to Max of Subvention End Date in Subvention txn Details for Subvention Txn Id:"
									+ txnId);
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data available in Subvention and Subvention Txn Details");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add(
					"Subvention End Date in Subvention Details is equal to Max of Subvention End Date in Subvention txn Details ");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		return true;
	}

}
