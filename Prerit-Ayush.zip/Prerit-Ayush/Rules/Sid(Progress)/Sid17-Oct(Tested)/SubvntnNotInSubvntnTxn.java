package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class SubvntnNotInSubvntnTxn implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> subvetionTxnDetails = MVEL.eval("loan_account.?subvention_txn_details", context, List.class);
		List<Map<?, ?>> subvetionDetails = MVEL.eval("loan_account.?subvention_details", context, List.class);
		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		if (subvetionDetails != null && subvetionTxnDetails != null) {
			Iterator<Map<?, ?>> subvetionItr = subvetionDetails.iterator();
			List<BigDecimal> subvetionLoanIdList = new ArrayList<>();
			List<BigDecimal> subvetionIdList = new ArrayList<>();
			while (subvetionItr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) subvetionItr.next();
				BigDecimal subvetionLoanId = new BigDecimal(0);
				BigDecimal subvetionId = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if ("LOANID".equals(entries.getKey()))
						subvetionLoanId = (BigDecimal) entries.getValue();
					if ("ID".equals(entries.getKey()))
						subvetionId = (BigDecimal) entries.getValue();
				}
				subvetionIdList.add(subvetionId);
				subvetionLoanIdList.add(subvetionLoanId);

			}
			Iterator<Map<?, ?>> subvetionTxnItr = subvetionTxnDetails.iterator();
			while (subvetionTxnItr.hasNext()) {
				Map<String, String> mapValue = (Map<String, String>) subvetionTxnItr.next();
				BigDecimal subventionTxnLoanId = new BigDecimal(0);
				BigDecimal txnSubvetionId = new BigDecimal(0);
				BigDecimal txnId = new BigDecimal(0);
				for (Map.Entry entries : mapValue.entrySet()) {
					if ("LOANID".equals(entries.getKey()))
						subventionTxnLoanId = (BigDecimal) entries.getValue();
					if ("SUBVENTION_ID".equals(entries.getKey()))
						txnSubvetionId = (BigDecimal) entries.getValue();
					if ("ID".equals(entries.getKey()))
						txnId = (BigDecimal) entries.getValue();
				}
				if ((subvetionIdList.contains(txnSubvetionId)) && (subvetionLoanIdList.contains(subventionTxnLoanId))) {
					// do nothing
				} else {
					logList.add("Subvetion Details are not available in Subvetion Txn Details for Subvetion Txn Id:"
							+ txnId);
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data avialable in subvention and Subvetion Txn Details");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add("Subvetion Details are available in Subvetion Txn Details ");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		return true;
	}

}
