package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class MandFieldChkInTdsDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> tdsDetails = MVEL.eval("loan_account.?tds_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<>();
		String loanStatus = null;
		try {
			loanStatus = (String) ctx.getValue("loan_account/STATUS",
					String.class);
		} catch (Exception e) {
			logList.add("Exception in Retrieving data from Loan Account");
		}
		boolean resultFlag = true;
		if (tdsDetails != null) {
			Iterator<Map<?, ?>> itr = tdsDetails.iterator();
			while (itr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) itr.next();
				BigDecimal chargeCode = new BigDecimal(0);
				BigDecimal loanId = new BigDecimal(0);
				BigDecimal chargeCodeMstId = new BigDecimal(0);
				BigDecimal currentStatus = new BigDecimal(0);
				BigDecimal recievablePayableAmount = new BigDecimal(0);
				BigDecimal tdsAmount = new BigDecimal(0);
				BigDecimal tdsId = new BigDecimal(0);
				Date dueDate = null;
				String mcStatus = null;
				for (Map.Entry entries : mapValues.entrySet()) {
					if ("ID".equals(entries.getKey()))
						tdsId = (BigDecimal) entries.getValue();
					if ("CHARGECODE".equals(entries.getKey()))
						chargeCode = (BigDecimal) entries.getValue();
					if ("LOANID".equals(entries.getKey()))
						loanId = (BigDecimal) entries.getValue();
					if ("CHARGECODE_MST_ID".equals(entries.getKey()))
						chargeCodeMstId = (BigDecimal) entries.getValue();
					if ("CURRENT_STATUS".equals(entries.getKey()))
						currentStatus = (BigDecimal) entries.getValue();
					if ("DUEDATE".equals(entries.getKey()))
						dueDate = (Date) entries.getValue();
					if ("TDS_AMT".equals(entries.getKey()))
						tdsAmount = (BigDecimal) entries.getValue();
					if ("RECEIVABLE_PAYABLE_AMT".equals(entries.getKey()))
						recievablePayableAmount = (BigDecimal) entries.getValue();
					if ("MC_STATUS".equals(entries.getKey()))
						mcStatus = (String) entries.getValue();

				}
				if ((chargeCode == null || loanId == null || chargeCodeMstId == null || currentStatus == null
						|| dueDate == null || tdsAmount == null || recievablePayableAmount == null || mcStatus == null)
						&& ("A".equals(loanStatus))) {
					logList.add("Mandatory fields in Lms Tds Details is Null for Tds Id:" + tdsId);
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data available in Tds details");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add("Mandatory fields in Tds Details are not Null");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}

