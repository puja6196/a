package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class NullChkPyblTxnIdRcvbPybId implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> tdsDetails = MVEL.eval("loan_account.?tds_details", context, List.class);
		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		if (tdsDetails != null) {
			Iterator<Map<?, ?>> itr = tdsDetails.iterator();
			while (itr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) itr.next();
				String additionalTds = null;
				BigDecimal payableTxnId = new BigDecimal(0);
				BigDecimal recievablePaybleTxnId = new BigDecimal(0);
				BigDecimal tdsDetailsId = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if ("RECEIVABLE_PAYABLE_TXN_ID".equals(entries.getKey()))
						recievablePaybleTxnId = (BigDecimal) entries.getValue();
					if ("PAYABLE_TXN_ID".equals(entries.getKey()))
						payableTxnId = (BigDecimal) entries.getValue();
					if ("ADDITIONAL_TDS".equals(entries.getKey()))
						additionalTds = (String) entries.getValue();
					if ("ID".equals(entries.getKey()))
						tdsDetailsId = (BigDecimal) entries.getValue();
				}
				if (("Y".equals(additionalTds)) && (recievablePaybleTxnId != null || payableTxnId == null)) {
					logList.add(
							"Payble Txn Id is null and Recievable Payble Txn Id is not null with Additional Status Y for Tds Details Id:"
									+ tdsDetailsId);
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data available in Tds Details");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add(
					"Payble Txn Id is not null or Recievable Payble Txn Id is null with Additional Status except Y");
        logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
