package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChrgEvntNtNullInChargeExcDtl implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
      List<Map<?,?>> chargeExecDtl=MVEL.eval("loan_account.?sub_loan_details.?charge_exec_details", context, List.class);
      List<String> logList=new ArrayList<>();
      boolean resultFlag=true;
      if(chargeExecDtl!=null){
    	  Iterator<Map<?, ?>> itr=chargeExecDtl.iterator();
    	  BigDecimal chargeEvent=new BigDecimal(0);
    	  BigDecimal chargeId=new BigDecimal(0);
    	  while(itr.hasNext()){
    		  Map<String, String> mapValues=(Map<String, String>) itr.next();
    		  for(Map.Entry entries:mapValues.entrySet()){
    			  if("CHARGE_EVENT".equals(entries.getKey()))
    				  chargeEvent=(BigDecimal) entries.getValue();
    			  if("ID".equals(entries.getKey()))
    				  chargeId=(BigDecimal)entries.getValue();
    		  }
    		  if(chargeEvent==null){
    			  logList.add("Charge Event in Charge Exec Details is Null for Charge Id:"+chargeId);
    			  resultFlag=false;
    		  }
    	  }
      }
      else{
    	  logList.add("No data available in Charge Exec Details ");
    	  resultFlag=false;
      }
        if(resultFlag)
        	logList.add("Charge Event in Charge Exec Details is not Null");
        logger.setLog(logList);
		return resultFlag;
	}
	
	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
