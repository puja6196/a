package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class PartyTypeNotNullInParty implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> partyDetails = MVEL.eval("loan_account.?cas_loan_app_details.?party_details", context,
				List.class);
		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		if (partyDetails != null) {
			Iterator<Map<?, ?>> itr = partyDetails.iterator();
			while (itr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) itr.next();
				String partyType = null;
				BigDecimal partyId = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if ("PARTY_TYPE".equals(entries.getKey()))
						partyType = (String) entries.getValue();
					if ("ID".equals(entries.getKey()))
						partyId = (BigDecimal) entries.getValue();
				}
				if (partyType == null) {
					logList.add("Part Type in Party Details is Null for Party Id:" + partyId);
					resultFlag = false;
				}
			}
		} else {
			logList.add("No data available in Party Details");
			resultFlag = false;
		}

		if (resultFlag)
			logList.add("PartyType in Party Details is not Null");
		logger.setLog(logList);
		return resultFlag;
	}
	
	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
