package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFieldsCasApplication implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> subloandetails = MVEL.eval("loan_account.?sub_loan_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (subloandetails != null) {
			Iterator<Map<?, ?>> it = subloandetails.iterator();
			while (it.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal scheme = new BigDecimal(0);
				BigDecimal product = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("SCHEME").equals(entries.getKey()))
						scheme = (BigDecimal) entries.getValue();
					if (("PRODUCT").equals(entries.getKey()))
						product = (BigDecimal) entries.getValue();
				}
				if (scheme == null) {
					logList.add("SCHEME of Sub loan details is null.");
					returnFlag = false;
				}
				if (product == null) {
					logList.add("PRODUCT of sub loan details is null.");
					returnFlag = false;
				}
			}
			if (returnFlag) {
				logList.add("SCHEME,PRODUCT of sub loan details Is not null.");
			}
		} else {
			logList.add("Sub Loan Details are not avilable.");
			returnFlag = false;

		}

		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
