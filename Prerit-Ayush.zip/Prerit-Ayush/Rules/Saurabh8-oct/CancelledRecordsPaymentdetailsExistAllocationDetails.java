package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class CancelledRecordsPaymentdetailsExistAllocationDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> paymentdetails = MVEL.eval("loan_account.?payment_details", context, List.class);
		List<Map<?, ?>> allocationdetails = MVEL.eval("loan_account.?allocation_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		String paymentstatus = null;
		BigDecimal id = new BigDecimal(0);
		BigDecimal allocationreceiptpaymentid = new BigDecimal(0);
		String allocationstatus = null;
		BigDecimal vapid = new BigDecimal(0);
		BigDecimal vapidval = BigDecimal.ZERO;
		if (paymentdetails != null && allocationdetails != null) {
			Iterator<Map<?, ?>> paymentdtlit = paymentdetails.iterator();
			while (paymentdtlit.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) paymentdtlit.next();

				for (Map.Entry entries : mapValues.entrySet()) {
					if (("STATUS").equals(entries.getKey()))
						paymentstatus = entries.getValue().toString();
					if (("ID").equals(entries.getKey()))
						id = (BigDecimal) entries.getValue();
					if (("VAPID").equals(entries.getKey()))
						vapid = (BigDecimal) entries.getValue();
				}
				Iterator<Map<?, ?>> allocationdtlitr = allocationdetails.iterator();
				while (allocationdtlitr.hasNext()) {
					Map<String, String> mapValue = (Map<String, String>) allocationdtlitr.next();
					for (Map.Entry entry : mapValue.entrySet()) {
						if (("STATUS").equals(entry.getKey()))
							allocationstatus = entry.getValue().toString();
						if (("RECEIPTPAYMENTID").equals(entry.getKey()))
							allocationreceiptpaymentid = (BigDecimal) entry.getValue();
					}
					if (vapid == null) {
						vapid = BigDecimal.ZERO;
					}
					if (vapid.compareTo(vapidval) == 0) {
						if ((id.compareTo(allocationreceiptpaymentid) == 0)
								&& (allocationstatus != "X" && allocationstatus != "B")) {
							if (("B".equalsIgnoreCase(paymentstatus)) && ("X".equalsIgnoreCase(paymentstatus))) {
								logList.add(
										"Cancelled or bounced records from payment details exist in allocation details for Id ="
												+ id);
								returnFlag = false;
							}
						}
					}
				}

			}
			if (returnFlag) {
				logList.add("Cancelled or bounced records from payment details not exist in allocation details.");
			}
		} else {
			logList.add("Payment details or Allocation details are not avilable");
			returnFlag = false;

		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
