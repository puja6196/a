package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class PricompandIntcompandChagecodeAdvicedetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> advicedetails = MVEL.eval("loan_account.?advice_details", context, List.class);
		boolean returnFlag = true;
		List<String> logList = new ArrayList<String>();
		if (advicedetails != null) {

			Iterator<Map<?, ?>> itr = advicedetails.iterator();
			while (itr.hasNext()) {
				Map<String, String> mValues = (Map<String, String>) itr.next();
				BigDecimal chargecode = new BigDecimal(0);
				BigDecimal princompreceived = new BigDecimal(0);
				BigDecimal intcompreceived = new BigDecimal(0);
				BigDecimal chargecodeval = new BigDecimal(9);
				BigDecimal loanid = new BigDecimal(0);
				BigDecimal vapid = new BigDecimal(0);
				BigDecimal vapidval = BigDecimal.ZERO;
				for (Map.Entry entries : mValues.entrySet()) {
					if (("CHARGECODE").equals(entries.getKey()))
						chargecode = (BigDecimal) entries.getValue();
					if (("PRINCOMP_RECEIVED").equals(entries.getKey()))
						princompreceived = (BigDecimal) entries.getValue();
					if (("INTCOMP_RECEIVED").equals(entries.getKey()))
						intcompreceived = (BigDecimal) entries.getValue();
					if (("LOANID").equals(entries.getKey()))
						loanid = (BigDecimal) entries.getValue();
					if (("VAPID").equals(entries.getKey()))
						vapid = (BigDecimal) entries.getValue();
				}
				if (vapid == null) {
					vapid = BigDecimal.ZERO;
				}
				if(vapid.compareTo(vapidval)==0){
				if (vapid.compareTo(chargecodeval) == 0) {
					if (chargecode.compareTo(chargecodeval) == 0) {
						// do nothing
					} else {
						if ((princompreceived.compareTo(BigDecimal.ZERO) == 1)
								&& (intcompreceived.compareTo(BigDecimal.ZERO) == 1)) {
							logList.add(
									"Principal Component Recevived and Interest Component Recevived is greater than zero for Charge Code other than 9 in advice details for LoanId ="
											+ loanid);
							returnFlag = false;
						}
					}
				}
			}
			}
			if (returnFlag) {
				logList.add(
						"Principal Component Recevived and Interest Component Recevived is not greater than zero for Charge Code is 9 in advice details.");
			}
		} else {
			logList.add("Advice details are not avilable.");
			returnFlag = false;
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
