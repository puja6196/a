package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class OriginalChequeCancelledLoanAdvice implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		List<Map<?, ?>> advicedetails = MVEL.eval("loan_account.?advice_details", context, List.class);
		List<Map<?, ?>> paymentdetails = MVEL.eval("loan_account.?payment_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		String advicestatus = null;
		BigDecimal advicechargecode = new BigDecimal(0);
		BigDecimal adviceReceivablePayableFlag = new BigDecimal(0);
		BigDecimal vapid = new BigDecimal(0);
		BigDecimal vapidval = BigDecimal.ZERO;
		String paymentstatus = null;
		BigDecimal advicechargecodeval = new BigDecimal(37);
		BigDecimal adviceReceivablePayableFlagval = new BigDecimal(61099);
		BigDecimal loanid = new BigDecimal(0);
		if (advicedetails != null && paymentdetails != null) {
			Iterator<Map<?, ?>> paymentdtlit = paymentdetails.iterator();
			while (paymentdtlit.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) paymentdtlit.next();

				for (Map.Entry entries : mapValues.entrySet()) {
					if (("STATUS").equals(entries.getKey()))
						paymentstatus = entries.getValue().toString();

				}
				Iterator<Map<?, ?>> advicedtlitr = advicedetails.iterator();
				while (advicedtlitr.hasNext()) {
					Map<String, String> mapValue = (Map<String, String>) advicedtlitr.next();
					for (Map.Entry entry : mapValue.entrySet()) {
						if (("STATUS").equals(entry.getKey()))
							advicestatus = entry.getValue().toString();
						if (("CHARGECODE").equals(entry.getKey()))
							advicechargecode = (BigDecimal) entry.getValue();
						if (("RECEIVABLE_PAYABLE_FLAG").equals(entry.getKey()))
							adviceReceivablePayableFlag = (BigDecimal) entry.getValue();
						if(("LOANID").equals(entry.getKey()))
							loanid = (BigDecimal) entry.getValue();
						if (("VAPID").equals(entry.getKey()))
							vapid = (BigDecimal) entry.getValue();

					}
					if (vapid == null) {
						vapid = BigDecimal.ZERO;
					}
					if (vapid.compareTo(vapidval) == 0) {
						if (("X".equalsIgnoreCase(paymentstatus))) {
							if ("A".equalsIgnoreCase(advicestatus)
									&& (advicechargecode.compareTo(advicechargecodeval) == 0)
									&& (adviceReceivablePayableFlag.compareTo(adviceReceivablePayableFlagval) == 0)) {
								logList.add("Original Cheque is cancelled in advice details for LoanId ="+loanid);
								returnFlag = false;

							}
						}
					}
				}

			}

			if (returnFlag) {
				logList.add("Original Cheque is not cancelled in advice details .");

			}

		} else {
			logList.add("Advice details or Payment details are not avilable.");
			returnFlag = false;

		}

		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
