package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalAmountNotEqualPrincipalComponentDisbursalDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		List<Map<?, ?>> disbursaldetails = MVEL.eval("loan_account.?disbursal_details", context, List.class);
		List<Map<?, ?>> loanrepayment = MVEL.eval("loan_account.?loan_repayment", context, List.class);

		BigDecimal id = (BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
		BigDecimal disbursalstatusid = (BigDecimal) ctx.getValue("/loan_account/DISBURSAL_STATUS_ID", BigDecimal.class);
		String status = (String) ctx.getValue("/loan_account/STATUS", String.class);
		BigDecimal disbursalstatusidval = new BigDecimal(2860);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;

		BigDecimal disbursalamt = new BigDecimal(0);
		BigDecimal principalcomponent = new BigDecimal(0);
		BigDecimal loaniddis = new BigDecimal(0);
		BigDecimal loanidrepay = new BigDecimal(0);
		String disbursalstatus = null;
		BigDecimal sumdisbursalamt = new BigDecimal(0);
		BigDecimal sumprincipal = new BigDecimal(0);
		BigDecimal vapid = new BigDecimal(0);
		BigDecimal vapidval = BigDecimal.ZERO;
		if (disbursaldetails != null && loanrepayment != null) {

			Iterator<Map<?, ?>> disbursaldetailsit = disbursaldetails.iterator();
			while (disbursaldetailsit.hasNext()) {

				Map<String, String> mapValues = (Map<String, String>) disbursaldetailsit.next();

				for (Map.Entry entries : mapValues.entrySet()) {
					if (("LOANID").equals(entries.getKey()))
						loaniddis = (BigDecimal) entries.getValue();
					if (("DISBURSAL_AMT").equals(entries.getKey()))
						disbursalamt = (BigDecimal) entries.getValue();
					if (("DISBURSAL_STATUS").equals(entries.getKey()))
						disbursalstatus = entries.getValue().toString();
					if (("VAPID").equals(entries.getKey()))
						vapid = (BigDecimal) entries.getValue();
				}
				Iterator<Map<?, ?>> loanrepaymentit = loanrepayment.iterator();
				while (loanrepaymentit.hasNext()) {
					Map<String, String> mapValue = (Map<String, String>) loanrepaymentit.next();
					for (Map.Entry entry : mapValue.entrySet()) {
						if (("LOANID").equals(entry.getKey()))
							loanidrepay = (BigDecimal) entry.getValue();
						if (("PRINCIPAL_COMPONENT").equals(entry.getKey()))
							principalcomponent = (BigDecimal) entry.getValue();
					}
					if (vapid == null) {
						vapid = BigDecimal.ZERO;
					}
					if (vapid.compareTo(vapidval) == 0) {
						if ((id.compareTo(loaniddis) == 0) && ("A".equalsIgnoreCase(status))
								&& (disbursalstatusid.compareTo(disbursalstatusidval) == 0)
								&& disbursalstatus.equalsIgnoreCase("A")) {
							sumdisbursalamt = sumdisbursalamt.add(disbursalamt);
						}
						if ((loanidrepay.compareTo(loaniddis) == 0)) {
							sumprincipal = sumprincipal.add(principalcomponent);
						}
					}

				}

			}

			if ((sumdisbursalamt.compareTo(sumprincipal) == 0)) {
				// do nothing

			} else {
				logList.add(
						"Disbursed active Contracts where sum of disbursal amount is not equal to sum of principal component.");
				returnFlag = false;
			}
			if (returnFlag) {
				logList.add(
						"Disbursed active Contracts where sum of disbursal amount is  equal to sum of principal component.");
			}
		} else {
			logList.add("Disbursal details and Loan Repayment are not avilable.");
			returnFlag = false;
		}

		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
