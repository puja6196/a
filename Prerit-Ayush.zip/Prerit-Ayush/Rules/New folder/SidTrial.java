package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class SidTrial implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		 List<Map<?,?>> termHdrDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		 List<Map<?,?>> termDtlDetails = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
		 Boolean resultFlag=true;
			BigDecimal HdrId=new BigDecimal(0);
			 List<String> logList = new ArrayList<>();
			 if(termHdrDetails!=null)
				{
				 Iterator<Map<?, ?>> itr = termHdrDetails.iterator();
				 List l=new ArrayList<>();
	          while (itr.hasNext())
						
	             {
		                  Map<String,String> mapValues = (Map<String, String>) itr.next();
		                  for (Map.Entry entries : mapValues.entrySet()){
		                	  if(("ID").equals(entries.getKey()))
		                		  HdrId=(BigDecimal) entries.getValue(); 
		                         
		                  }
		          l.add(HdrId);        
	             }
	          
	          Iterator<Map<?, ?>> DtlItr = termDtlDetails.iterator(); 
	          BigDecimal terminationId=new BigDecimal(0);
	          BigDecimal dtlId=new BigDecimal(0);
	          while (DtlItr.hasNext())
					
	             {
		                  Map<String,String> mapValues = (Map<String, String>) DtlItr.next();
		                  for (Map.Entry entries : mapValues.entrySet()){
		                	  if (("TERMINATIONID").equals(entries.getKey()))
                   			{
                   				
                   				terminationId = (BigDecimal) entries.getValue();
                   				
                   		     } 
		                	  if (("ID").equals(entries.getKey()))
	                   			{
	                   				
	                   				dtlId = (BigDecimal) entries.getValue();
	                   				
	                   		     } 
		                	 
		                  }
		                  if(!(l.contains(terminationId))){
		                	  logList.add("termination header not in Termination details for Termination Dtl Id: "+dtlId);
		                	  resultFlag=false;
		              
		                  }
		                  
		                  
	             }
	          

				}
			 else{
				 logList.add("No data available in Termination header");
				 resultFlag=false;
			 }
			 
			 
			if(resultFlag)
				logList.add("Termination Headre is present in Termination Details");
			logger.setLog(logList);
			 
		return resultFlag;
				
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
