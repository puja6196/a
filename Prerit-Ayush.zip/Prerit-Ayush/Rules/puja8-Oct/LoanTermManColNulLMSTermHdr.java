package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanTermManColNulLMSTermHdr implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{
		JXPathContext ctx = JXPathContext.newContext(context);
		   List<String> logList = new ArrayList<>();
		   BigDecimal loanId=(BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
		   String loanAccStatus=(String)ctx.getValue("/loan_account/STATUS", String.class);
		
		   Boolean resultFlag=true;
		   List<Map<?,?>> terminationHdrDtl  = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);

	         if(terminationHdrDtl!=null)
	               {
						
		              Iterator<Map<?, ?>> it = terminationHdrDtl.iterator();
		              while (it.hasNext())
							
		                 {
			                  Map<String,String> mapValues = (Map<String, String>) it.next();
			
			                  BigDecimal termHdrLoanId=new BigDecimal(0);
			                  BigDecimal termHdrId=new BigDecimal(0);
			                  
			                      for (Map.Entry entries : mapValues.entrySet())
			                            {
				                          if(("LOANID").equals(entries.getKey()))
				                           termHdrLoanId=(BigDecimal) entries.getValue(); 
				                         
				                          if(("ID").equals(entries.getKey()))
					                           termHdrId=(BigDecimal) entries.getValue();
				                                 
				                         
				
			                                 
			                            }
			                      if(termHdrLoanId==null)
			                    	 
			                      {
			                    	  termHdrLoanId=BigDecimal.ZERO;
			                    	  if((loanAccStatus=="A"))
			                    	  {
			                    		  if(termHdrLoanId.compareTo(loanId)==0)
			                    		  {
			                    	  
			                                  logList.add("Mandatory columns are null in LMS_TERMINATION_HDR table for Termination Id:"+termHdrId);
			                                  resultFlag=false;
			                    		  }
			                      
			                      }
		                 }
		                 }
			                      if(resultFlag)
			                      {
			                  
			                    	  logList.add("Mandatory columns are not null in LMS_TERMINATION_HDR table.");
			                      
			                      
			                      
			                      }
			                      
	               }
		              else
		              {
		              logList.add("No record available in Termination Hdr Detail");
		              }
	         
	         logger.setLog(logList);
	         return resultFlag;
	
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
