package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldsKnockoff implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> knockdetails = MVEL.eval("loan_account.?knockoff_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (knockdetails != null) {
			Iterator<Map<?, ?>> knockdetailsit = knockdetails.iterator();
			while (knockdetailsit.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) knockdetailsit.next();
				BigDecimal id = new BigDecimal(0);
				BigDecimal bptypeid = new BigDecimal(0);
				BigDecimal currencymstid = new BigDecimal(0);
				String customerno = null;
				BigDecimal knockoffAmount = new BigDecimal(0);
				BigDecimal receiptpaymentid = new BigDecimal(0);
				BigDecimal receivablepayableflag = new BigDecimal(0);
				BigDecimal receivablepayabletxnid = new BigDecimal(0);
				BigDecimal charecode = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if(("ID").equals(entries.getKey()))
						id = (BigDecimal) entries.getValue();
					if(("BPTYPE_ID").equals(entries.getKey()))
						bptypeid = (BigDecimal) entries.getValue();
					if(("CURRENCY_MST_ID").equals(entries.getKey()))
						currencymstid = (BigDecimal) entries.getValue();
					if(("CUSTOMER_NO").equals(entries.getKey()))
						customerno = entries.getValue().toString();
					if(("KNOCKOFF_AMOUNT").equals(entries.getKey()))
						knockoffAmount = (BigDecimal) entries.getValue();
					if(("RECEIPTPAYMENTID").equals(entries.getKey()))
						receiptpaymentid = (BigDecimal) entries.getValue();
					if(("RECEIVABLE_PAYABLE_FLAG").equals(entries.getKey()))
						receivablepayableflag = (BigDecimal) entries.getValue();
					if(("RECEIVABLE_PAYABLE_TXN_ID").equals(entries.getKey()))
						receivablepayabletxnid = (BigDecimal) entries.getValue();
					if(("CHARGECODE").equals(entries.getKey()))
						charecode = (BigDecimal) entries.getValue();
				}
				if(id==null){
					logList.add("Id is null in Knock Details.");
					returnFlag=false;
				}
				if(bptypeid==null){
					logList.add("BP Type Id is null in Knock Details.");
					returnFlag=false;
				}
				if(currencymstid==null){
					logList.add("Currency Mst Id is null in Knock Details.");
					returnFlag=false;
				}
				if(customerno==null){
					logList.add("Customer Number is null in Knock Details.");
					returnFlag=false;
				}
				if(knockoffAmount==null){
					logList.add("KnockOff Amount is null in Knock Details.");
					returnFlag=false;
				}
				if(receiptpaymentid==null){
					logList.add("Receipt Payment Id is null in Knock Details.");
					returnFlag=false;
				}
				if(receivablepayableflag==null){
					logList.add("Receivable Payable Flag is null in Knock Details.");
					returnFlag=false;
				}
				if(receivablepayabletxnid==null){
					logList.add("Receivable Payable transaction Id is null in Knock Details.");
					returnFlag=false;
				}
				if(charecode==null){
					logList.add("Charge Code is null in Knock Details.");
					returnFlag=false;
				}
			}
			if(returnFlag){
				logList.add("Id,BP Type Id,Currency Mst Id,Customer Number,KnockOff Amount,Receipt Payment Id,Receivable Payable Flag,Receivable Payable transaction Id,Charge Code are not null in Knock Details.");
			}
		}else{
			logList.add("Knock Details are not avilable.");
			returnFlag=false;
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		
		return true;
	}

}
