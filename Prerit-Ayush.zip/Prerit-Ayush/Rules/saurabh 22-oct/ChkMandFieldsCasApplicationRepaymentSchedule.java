package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldsCasApplicationRepaymentSchedule implements RuleExecutor{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal moratoriumtype = (BigDecimal) ctx.getValue("/loan_account/sub_loan_details/rp_schedule_details/MORATORIUM_TYPE",BigDecimal.class);
		BigDecimal moratorium = (BigDecimal) ctx.getValue("/loan_account/sub_loan_details/rp_schedule_details/MORATORIUM",BigDecimal.class);
		BigDecimal numberofdisbursal = (BigDecimal) ctx.getValue("/loan_account/sub_loan_details/rp_schedule_details/NUMBER_OF_DISBURSAL",BigDecimal.class);
		BigDecimal anchortype = (BigDecimal) ctx.getValue("/loan_account/sub_loan_details/rp_schedule_details/ANCHOR_TYPE",BigDecimal.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if(moratoriumtype==null){
			logList.add("Moratorium Type is null in Repayment Schedule.");
			returnFlag=false;
		}
		if(moratorium==null){
			logList.add("Moratorium is null in Repayment Schedule.");
		    returnFlag=false;		}
		if(numberofdisbursal==null){
			logList.add("Number of disbursal is null in Repayment Schedule.");
			returnFlag=false;
		}
		if(anchortype==null){
			logList.add("Anchor Type is null in Repayment Schedule.");
			returnFlag=false;
		}
		if(returnFlag){
			logList.add("Moratorium Type ,Moratorium ,Number of disbursal and Anchor Type is not null in Repayment Schedule.");
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
