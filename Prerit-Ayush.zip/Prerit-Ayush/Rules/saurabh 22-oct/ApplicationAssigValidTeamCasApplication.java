package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ApplicationAssigValidTeamCasApplication implements RuleExecutor{

	
	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> loantaskmapdetails = MVEL.eval("loan_account.?cas_loan_app_details.?loan_task_map_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		
		if (loantaskmapdetails != null) {
			Iterator<Map<?, ?>> loantaskmapdetailsit = loantaskmapdetails.iterator();
			while (loantaskmapdetailsit.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) loantaskmapdetailsit.next();
				String groupassignee=null;
				BigDecimal id = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if(("GROUP_ASSIGNEE").equals(entries.getKey()))
						groupassignee = entries.getValue().toString();
					if(("ID").equals(entries.getKey()))
						id = (BigDecimal) entries.getValue();
				}
				if(groupassignee.length()<=35)
				{
					logList.add("Group Assignee length is less than 35 in Loan task map details for id ="+id);
					returnFlag=false;
				}
				if(groupassignee==null)
				{
					logList.add("Group Assignee is null in Loan task map details for id ="+id);
					returnFlag=false;
				}
			  
			}
			if(returnFlag){
				logList.add("Group Assignee not length than 35 and not null in Loan task map details.");
			}
		}else{
			logList.add("Loan task mapping details is not avilable.");
			returnFlag=false;
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
