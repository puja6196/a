package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldsPdcInstrumentType implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> pdcdetails = MVEL.eval("loan_account.?pdc_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (pdcdetails != null) {
			Iterator<Map<?, ?>> pdcdetailsit = pdcdetails.iterator();
			while (pdcdetailsit.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) pdcdetailsit.next();
				BigDecimal instrumenttype = new BigDecimal(0);
				BigDecimal loanid = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if(("INSTRUMENT_TYPE").equals(entries.getKey()))
						instrumenttype = (BigDecimal) entries.getValue();
					if(("LOANID").equals(entries.getKey()))
						loanid = (BigDecimal) entries.getValue();
				}
				if(instrumenttype==null){
					logList.add("Instrument Type is null in Pdc Details for LoanId ="+loanid);
					returnFlag=false;
				}
			}
			if(returnFlag){
				logList.add("Instrument Type is not null in Pdc Details.");
			}
		}else{
			logList.add("Pdc Details are not avilable.");
			returnFlag=false;
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		
		return true;
	}

}
