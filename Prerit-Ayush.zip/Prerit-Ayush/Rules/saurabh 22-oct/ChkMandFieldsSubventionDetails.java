package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldsSubventionDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> subventiondetails = MVEL.eval("loan_account.?subvention_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		if (subventiondetails != null) {
			Iterator<Map<?, ?>> subventiondetailsit = subventiondetails.iterator();
			while (subventiondetailsit.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) subventiondetailsit.next();
				BigDecimal bptypeid = new BigDecimal(0);
				BigDecimal businesspartnerid = new BigDecimal(0);
				Date subventiovendate =null;
				String loanaccountno = null;
				BigDecimal loanid = new BigDecimal(0);
				Date subventionstartdate = null;
				BigDecimal subventionbasis = new BigDecimal(0);
				BigDecimal subventionpercentage = new BigDecimal(0);
				BigDecimal subventiontype = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()) {
					if(("BPTYPE_ID").equals(entries.getKey()))
						bptypeid = (BigDecimal) entries.getValue();
					if(("BUSINESSPARTNER_ID").equals(entries.getKey()))
						businesspartnerid = (BigDecimal) entries.getValue();
					if(("SUBVENTION_END_DATE").equals(entries.getKey()))
						subventiovendate = (Date) entries.getValue();
					if(("LOAN_ACCOUNT_NO").equals(entries.getKey()))
						loanaccountno = entries.getValue().toString();
					if(("LOANID").equals(entries.getKey()))
						loanid = (BigDecimal) entries.getValue();
					if(("SUBVENTION_START_DATE").equals(entries.getKey()))
						subventionstartdate = (Date) entries.getValue();
					if(("SUBVENTION_BASIS").equals(entries.getKey()))
						subventionbasis = (BigDecimal) entries.getValue();
					if(("SUBVENTION_PERCENTAGE").equals(entries.getKey()))
						subventionpercentage = (BigDecimal) entries.getValue();
					if(("SUBVENTION_TYPE").equals(entries.getKey()))
						subventiontype = (BigDecimal) entries.getValue();
				}
				if(bptypeid==null){
					logList.add("BPTYPE is null in Subvention Details.");
					returnFlag=false;
				}
				if(businesspartnerid==null){
					logList.add("Business Partner Id is null in Subvention Details.");
					returnFlag=false;
				}
				if(subventiovendate==null){
					logList.add("Subvention Date is null in Subvention Details.");
					returnFlag=false;
				}
				if(loanaccountno==null){
					logList.add("Loan Account Number is null in Subvention Details.");
					returnFlag=false;
				}
				if(loanid==null){
					logList.add("Loan Id is null in Subvention Details");
					returnFlag=false;
				}
				if(subventionstartdate==null){
					logList.add("Subvention Start Date is null in Subvention Details.");
					returnFlag=false;
				}
				if(subventionpercentage==null){
					logList.add("Subvention Percentage is null in Subvention Details.");
					returnFlag=false;
				}
				if(subventionbasis==null){
					logList.add("Subvention Basis is null in Subvention Details");
					returnFlag=false;
				}
				if(subventiontype==null){
					logList.add("Subvention Type is null in Subvention Details.");
					returnFlag=false;
				}
			}
			if(returnFlag){
				logList.add("BPTYPE ,Business Partner Id ,Subvention Date ,Loan Account Number ,Loan Id ,Subvention Start Date ,Subvention Percentage ,Subvention Basis ,Subvention Type are not null in Subvention Details.");
			}
		}else{
			logList.add("Subvention Details are not avilable.");
			returnFlag=false;
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		
		return true;
	}

}
