package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RecordsPresentSubventionTxnDetailslNotInSubventionDetails implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> subventiondetails = MVEL.eval("loan_account.?subvention_details", context, List.class);
		List<Map<?, ?>> subventiontxndetails = MVEL.eval("loan_account.?subvention_txn_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		BigDecimal iddtl = new BigDecimal(0);
		BigDecimal loaniddtl = new BigDecimal(0);
		BigDecimal loanidtxndtl = new BigDecimal(0);
		BigDecimal subventionidtxndtl = new BigDecimal(0);
		List<BigDecimal> loaniddtlval = new ArrayList<BigDecimal>();
		
		if (subventiondetails != null && subventiontxndetails != null) {
			Iterator<Map<?, ?>> subventiondetailsit = subventiondetails.iterator();
			while (subventiondetailsit.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) subventiondetailsit.next();
				
				for (Map.Entry entries : mapValues.entrySet()) {
					if(("ID").equals(entries.getKey()))
						iddtl = (BigDecimal) entries.getValue();
					if(("LOANID").equals(entries.getKey()))
						loaniddtl = (BigDecimal) entries.getValue();
				}
				
			
				Iterator<Map<?, ?>> subventiontxndtlitr = subventiontxndetails.iterator();
				while (subventiontxndtlitr.hasNext()) {
					Map<String, String> mapValue = (Map<String, String>) subventiontxndtlitr.next();
					for (Map.Entry entry : mapValue.entrySet()) {
						if(("LOANID").equals(entry.getKey()))
							loanidtxndtl = (BigDecimal) entry.getValue();
						if(("SUBVENTION_ID").equals(entry.getKey()))
							subventionidtxndtl = (BigDecimal) entry.getValue();
					}
					
					if((iddtl.compareTo(subventionidtxndtl)==0) && (loaniddtl.compareTo(loanidtxndtl)==0)){
						loaniddtlval.add(loaniddtl);
					}	
				}
			}
			
			if(loaniddtlval.contains(loanidtxndtl)){
				//do nothing
			}else{
				logList.add("Records are in Subvention Details are not Present in Subvention Transaction Details.");
				returnFlag=false;
				
			}
			
			
			if(returnFlag){
				logList.add("Records are in Subvention Details are  Present in Subvention Transaction Details.");
			}
		}else{
			logList.add("Subvention Details and Subvention Transaction Details are not avilable.");
		}
		
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
				return true;
	}

}
