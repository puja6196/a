package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.JXPathContext;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandFieldsCasApplicationCustomer implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {

		JXPathContext ctx = JXPathContext.newContext(context);
		String cifnumber = (String) ctx
				.getValue("/loan_account/cas_loan_app_details/party_details/customer_details/CIFNUMBER", String.class);
		String customernumber = (String) ctx.getValue(
				"/loan_account/cas_loan_app_details/party_details/customer_details/CUSTOMER_NUMBER", String.class);
		String customertype = (String) ctx.getValue(
				"/loan_account/cas_loan_app_details/party_details/customer_details/CUSTOMER_TYPE", String.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;

		if (cifnumber == null) {
			logList.add("Cif number is Null in Customer Details.");
			returnFlag = false;
		}
		if (customernumber == null) {
			logList.add("Customer number is null in Customer Details.");
			returnFlag = false;
		}
		if (customertype == null) {
			logList.add("Customer type is null in Customer Details.");
			returnFlag = false;
		}

		if (returnFlag) {
			logList.add("Cif Number,Customer Number and Customer type are not null in Customer details.");
			
		}

		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
