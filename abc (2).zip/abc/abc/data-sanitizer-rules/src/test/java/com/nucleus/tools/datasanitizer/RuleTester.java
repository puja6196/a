package com.nucleus.tools.datasanitizer;

import java.io.FileInputStream;

import org.apache.commons.lang.SerializationUtils;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.nucleus.tools.datasanitizer.lms.ChkManFldsNullLMSSubTxnDtl;
import com.nucleus.tools.datasanitizer.lms.LoanRepaymentEffectiveIRNull;
import com.nucleus.tools.datasanitizer.lms.LoanTerRecNotLmsTermDtl;
import com.nucleus.tools.datasanitizer.lms.SidTrial;
import com.nucleus.tools.datasanitizer.lms.SubDateNotEqualMinSubTxnDate;
import com.nucleus.tools.datasanitizer.lms.TDS857;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RuleTester {
	
	@Test
	public static void main(String [] args) throws Exception{
		String inputFile = "5000834.ser";
		FileInputStream fileInputStream = new FileInputStream(new ClassPathResource(inputFile).getFile());
		RootObject root = (RootObject)SerializationUtils.deserialize(fileInputStream);
		Logger logger = new Logger(); 
		RuleExecutor rule = new SubDateNotEqualMinSubTxnDate();
		boolean shouldExecute = rule.shouldExecute(root);
		boolean result = rule.execute(root, logger);
		System.out.println(result);
		//System.out.println(root);
	}

}
 