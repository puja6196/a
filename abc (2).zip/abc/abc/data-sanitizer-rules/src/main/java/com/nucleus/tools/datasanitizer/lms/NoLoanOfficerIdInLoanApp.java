package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class NoLoanOfficerIdInLoanApp implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		BigDecimal loanOfficerId = new BigDecimal(0);
		List<String> logList = new ArrayList<>();
		boolean resultFlag = true;
		try {
			loanOfficerId = (BigDecimal) ctx.getValue("/loan_account/cas_loan_app_details/LOAN_OFFICER_ID",
					BigDecimal.class);
			
		} catch (Exception e) {
			logList.add("Exception while retrieving data from Cas Loan app Details");
		}
		if (loanOfficerId == null) {
			logList.add("Loan officer Id in Loan Application is null");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add("Loan officer Id in Loan Application is not null");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
