package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class PrabhashLmsReceiptPayDtl implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{
		List<Map<?,?>> paymentDetails = MVEL.eval("loan_account.?payment_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if(paymentDetails!=null)
		{
			Iterator<Map<?, ?>> it = paymentDetails.iterator();
			while(it.hasNext())
			{
				Map<String,String> mapValues = (Map<String, String>)it.next();
				BigDecimal id=new BigDecimal(0);
				String loanAccNum=null;
				String bpTypeId=null;
				String customerNum=null;
				String currenyMstId=null;
				String loanBranchId=null;
				String loanId=null;
				String status=null;
				String mcStatus=null;
				String productId=null;
				BigDecimal txnAmt=new BigDecimal(0);
				String paymentMode=null;
				String receiptPayType=null;
				String txnBranchId=null;
				String txnCurrencyMstId=null;
				Date txnDate=null;
				Date txnValueDate=null;
				String receiptAgainst=null;
				for(Map.Entry entries : mapValues.entrySet())
				{
					if("ID".equals(entries.getKey()))
						id=(BigDecimal) entries.getValue();
					if("LOAN_ACCOUNT_NO".equals(entries.getKey()))
							loanAccNum=entries.getValue().toString();
					if("BPTYPE_ID".equals(entries.getKey()))
						bpTypeId=entries.getValue().toString();
					if("CUSTOMER_NO".equals(entries.getKey()))
						customerNum=entries.getValue().toString();
					if("CURRENCY_MST_ID".equals(entries.getKey()))
						currenyMstId=entries.getValue().toString();
					if("LOAN_BRANCHID".equals(entries.getKey()))
						loanBranchId=entries.getValue().toString();
					if("LOANID".equals(entries.getKey()))
						loanId=entries.getValue().toString();
					if("STATUS".equals(entries.getKey()))
						status=entries.getValue().toString();
					if("MC_STATUS".equals(entries.getKey()))
						mcStatus=entries.getValue().toString();
					if("PRODUCTID".equals(entries.getKey()))
						productId=entries.getValue().toString();
					if("TRANSACTION_AMOUNT".equals(entries.getKey()))
						txnAmt=(BigDecimal) entries.getValue();
					if("PAYMENTMODE".equals(entries.getKey()))
						paymentMode= entries.getValue().toString();
					if("RECEIPTPAYMENT_TYPE".equals(entries.getKey()))
						receiptPayType=entries.getValue().toString();
					if("TXN_BRANCHID".equals(entries.getKey()))
						txnBranchId=entries.getValue().toString();
					if("TXN_CURRENCY_MST_ID".equals(entries.getKey()))
						txnCurrencyMstId=entries.getValue().toString();
					if("TRANSACTION_DATE".equals(entries.getKey()))
						txnDate=(Date) entries.getValue();
					if("TXN_VALUE_DATE".equals(entries.getKey()))
						txnValueDate=(Date) entries.getValue();
					if("RECEIPT_AGAINST".equals(entries.getKey()))
						receiptAgainst=entries.getValue().toString();
				}
				if("51129"!=receiptAgainst && (status!="X" || status!="B")){
					if(id==null){
						logList.add("Id is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(loanAccNum.isEmpty()){
						logList.add("Loan Account Number is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(customerNum.isEmpty()){
						logList.add("Customer Number is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(currenyMstId.isEmpty()){
						logList.add("Currency mst id is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(loanBranchId.isEmpty()){
						logList.add("Loan Branch id is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(mcStatus.isEmpty()){
						logList.add("MC status is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(productId.isEmpty()){
						logList.add("Product id is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(txnAmt==null){
						logList.add("Transaction amount is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(paymentMode.isEmpty()){
						logList.add("Payment mode is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(receiptPayType.isEmpty()){
						logList.add("Receipt pay type is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(txnBranchId.isEmpty()){
						logList.add("Transaction Branch Id is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(txnCurrencyMstId.isEmpty()){
						logList.add("Transaction Currency Mst Id is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(txnDate==null){
						logList.add("Transaction Date is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
					if(txnValueDate==null){
						logList.add("Transaction Value Date is empty for loan id: "+loanId+" receipt against <> 51129 and status is not 'x' or 'B'");
						resultFlag=false;
					}
				}
				
			}
			if(resultFlag)
			{
				logList.add("No mandatory fields are found empty");
			}
			
			
		}
		else
		{
			
			logList.add("Payment Details are available.");
			resultFlag=false;
			
		}
		logger.setLog(logList);
		return resultFlag;

	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}
	
	
	

}
