package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TDS858 implements RuleExecutor

{
	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		List<Map<?,?>> tdsDtls = MVEL.eval("loan_account.?tds_details", context, List.class);
		boolean returnFlag=true;
		List<String> logList = new ArrayList<>();
		if(tdsDtls!=null)
		{
    	Iterator<Map<?, ?>> it = tdsDtls.iterator();
			while (it.hasNext())
			{
				Map<String,String> mapValues = (Map<String, String>) it.next();
				String tdsStatus = null;
				BigDecimal cancltnRefId=new BigDecimal(0);
				BigDecimal tdsId=new BigDecimal(0);
				
				for (Map.Entry entries : mapValues.entrySet())
				{
					if(("MC_STATUS").equals(entries.getKey()))
						tdsStatus	 =(String)  entries.getValue().toString();
					if(("CANCELLATION_REF_ID").equals(entries.getKey()))
						cancltnRefId  = ((BigDecimal) entries.getValue());
					if(("ID").equals(entries.getKey()))
						tdsId  = ((BigDecimal) entries.getValue());
				}
				if((tdsStatus=="X")&&(cancltnRefId==null))
				{
					logList.add("LMS_TDS_DTL  where MC_STATUS is Cancelled and CANCELLATION_REF_ID is null for TDS Id:"+tdsId);
				    returnFlag=false;
				}
				}
			if(returnFlag)
			{
				logList.add("LMS_TDS_DTL  where MC_STATUS is not Cancelled and CANCELLATION_REF_ID is not null.");
			
			}}
	else
	{
		
		
		logList.add("No record available in TDS Details.");
		returnFlag=false;
	}
			logger.setLog(logList);
			return returnFlag;
	
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}
	}