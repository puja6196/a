package com.nucleus.tools.datasanitizer.lms;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.mvel2.MVEL;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class SubDateNotEqualMinSubTxnDate implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{    
		 boolean resultFlag=true;
		 Date minSubTxmStrtDate=null;
         List<String> logList = new ArrayList<String>();

         List<Map<?,?>> subvtnDtls = MVEL.eval("loan_account.?subvention_details", context, List.class);
         List<Map<?,?>> subvntnTxnDtls = MVEL.eval("loan_account.?subvention_txn_details", context, List.class);
         System.out.println(subvntnTxnDtls);
         
         if((subvtnDtls!=null)&&(subvntnTxnDtls!=null))
			{
        	 List<Date> list1=new ArrayList<>();
        	 List<BigDecimal> list2=new ArrayList<>();
        	 Date subStrtDate=null;
        	 BigDecimal subvntnId=new BigDecimal(0);
			 Iterator<Map<?, ?>> itr = subvtnDtls.iterator();
			
       while (itr.hasNext())
					
          {
	                  Map<String,String> mapValues = (Map<String, String>) itr.next();
	                  for (Map.Entry entries : mapValues.entrySet()){
	                	  if(("SUBVENTION_START_DATE").equals(entries.getKey()))
	                		  subStrtDate=(Date) entries.getValue(); 
	                	  if(("ID").equals(entries.getKey()))
	                		  subvntnId=(BigDecimal) entries.getValue(); 
	                         
	                  }
	              
	                  list1.add(subStrtDate);     
	                  list2.add(subvntnId);
	             
          }
       
       Iterator<Map<?, ?>> subTxnItr = subvntnTxnDtls.iterator(); 
  	 List<Date> l=new ArrayList<>();
       Date subvntnTxnStrtDate=null;
       BigDecimal subTxnId=new BigDecimal(0);
       BigDecimal loanId=new BigDecimal(0);
       while (subTxnItr.hasNext())
				
          {
	                  Map<String,String> mapValues = (Map<String, String>) subTxnItr.next();
	                  for (Map.Entry entries : mapValues.entrySet())
	                  {
	                	  if (("SUBVENTION_START_DATE").equals(entries.getKey()))
            			{
            				
	                		  subvntnTxnStrtDate = (Date) entries.getValue();
            				
            		     } 
	                	  
	                	  if (("SUBVENTION_ID").equals(entries.getKey()))
                			{
                				
	                		  subTxnId = (BigDecimal) entries.getValue();
                				
                		     } 
	                	  if (("LOANID").equals(entries.getKey()))
              			{
              				
	                		  loanId = (BigDecimal) entries.getValue();
              				
              		     } 
	                	  
		                	  
	                
	                  }
	                  
	                  if(subTxnId.compareTo(subvntnId)==0)
	                  {
	                	  l.add(subvntnTxnStrtDate);
	                	  minSubTxmStrtDate=Collections.min(l);
	                	  
	                	  
	                  }
	                 
	                  
	               
	                  if(list1.contains(minSubTxmStrtDate))
	                  {
	                	  
                       //do nothing	                	  
	                	  
	                	  
	                  }
	                  else
	                  {
	                	  
	                	  logList.add(" SUBVENTION_START_DATE present in LMS_SUBVENTION_DTL  is not equal to min of SUBVENTION_START_DATE in LMS_SUBVENTION_TXN_DTL table for Loan Id."+loanId);
	                	  resultFlag=false;
	                	 
	                	  
	                	  
	                  }
	                    
	              
	                  
          }
    
   
       if(resultFlag)
       {
     	  
     	  logList.add("SUBVENTION_START_DATE present in LMS_SUBVENTION_DTL  is equal to min of SUBVENTION_START_DATE in LMS_SUBVENTION_TXN_DTL table"); 
     	  
     	  
       }
       
  
			}
		 else
		 {
			 
			 logList.add("No record available either in Subvention Details or Subvention Transaction Details.");
			  resultFlag=false;
			 
		 }
		 
		 
	logger.setLog(logList);	 
	return resultFlag;

			
	}

	@Override
	public boolean shouldExecute(RootObject context) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
