package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RctPytDtlTranAmtNotEqlAlctAmt implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> paymentDetails = MVEL.eval("loan_account.?payment_details", context, List.class);
		List<Map<?, ?>> allocationDtl = MVEL.eval("loan_account.?allocation_details", context, List.class);
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<>();
		BigDecimal rctPytPaymentType = new BigDecimal(0);
		BigDecimal allocDtlPaymentType = new BigDecimal(0);
		BigDecimal transactionAmt = new BigDecimal(0);
		BigDecimal allocatedAmt = new BigDecimal(0);
		BigDecimal sumOfAllocAmt = new BigDecimal(0);
		BigDecimal paymtDtlId = new BigDecimal(0);
		BigDecimal allocReceitPaymtId = new BigDecimal(0);
		BigDecimal paymentDtlVapId = new BigDecimal(0);
		BigDecimal allocVapId = new BigDecimal(0);
		String allocStatus = null;
		String paymtDtlStatus = null;
		String loanActStatus = null;
		boolean resultFlag = true;
		try {
			loanActStatus = (String) ctx.getValue("/loan_account/STATUS", String.class);
		} catch (Exception e) {
			logList.add("Exception occured while retrieving data from Loan Account");
		}
		if (paymentDetails != null) {
			Iterator<Map<?, ?>> paymentItr = paymentDetails.iterator();
			while (paymentItr.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) paymentItr.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					try {
						if (("STATUS").equals(entries.getKey()))
							paymtDtlStatus = (String) entries.getValue();
						if (("ID").equals(entries.getKey()))
							paymtDtlId = (BigDecimal) entries.getValue();
						if (("RECEIPTPAYMENT_TYPE").equals(entries.getKey()))
							rctPytPaymentType = (BigDecimal) entries.getValue();
						if (("TRANSACTION_AMOUNT").equals(entries.getKey()))
							transactionAmt = (BigDecimal) entries.getValue();
						if (("VAPID").equals(entries.getKey()))
							paymentDtlVapId = (BigDecimal) entries.getValue();
						if (paymentDtlVapId == null)
							paymentDtlVapId = BigDecimal.ZERO;
					} catch (Exception e) {
						logList.add("Exception occured while retrieving data from Payment Details");
					}
				}
				Iterator<Map<?, ?>> allocItr = allocationDtl.iterator();
				while (allocItr.hasNext()) {
					Map<String, String> mapValue = (Map<String, String>) allocItr.next();
					for (Map.Entry entry : mapValue.entrySet()) {
						if (("RECEIPT_PAYMENT_TYPE").equals(entry.getKey()))
							allocDtlPaymentType = (BigDecimal) entry.getValue();
						if (("STATUS").equals(entry.getKey()))
							allocStatus = (String) entry.getValue();
						if (("RECEIPTPAYMENTID").equals(entry.getKey()))
							allocReceitPaymtId = (BigDecimal) entry.getValue();
						if (("ALLOCATEDAMT").equals(entry.getKey()))
							allocatedAmt = (BigDecimal) entry.getValue();
						if (("VAPID").equals(entry.getKey()))
							allocVapId = (BigDecimal) entry.getValue();
						if (allocVapId == null)
							allocVapId = BigDecimal.ZERO;

					}
					if ((paymtDtlId.compareTo(allocReceitPaymtId) == 0)
							&& (allocDtlPaymentType.compareTo(rctPytPaymentType) == 0)
							&& (!("X".equals(allocStatus) && "B".equals(allocStatus)))) {
						sumOfAllocAmt = sumOfAllocAmt.add(allocatedAmt);
					}
					if ((paymentDtlVapId.compareTo(BigDecimal.ZERO) == 0)
							&& (allocVapId.compareTo(BigDecimal.ZERO) == 0)&&(!(transactionAmt.compareTo(sumOfAllocAmt) == 0))&&(!("X".equals(paymtDtlStatus) && "B".equals(paymtDtlStatus)))&& ("A".equals(loanActStatus)))
									 {
							logList.add("Cleared Checks from RecietPayment Details where transaction amount:"
									+ transactionAmt + "is not equal to allocated amount" + allocatedAmt
									+ "for Payment Detail Id:" + paymtDtlId);
							resultFlag = false;
						}
					}
			}
		} else {
			logList.add("No data found in Payment Details");
			resultFlag = false;
		}
		if (resultFlag)
			logList.add(
					"Cleared Checks from RecietPayment Details where transaction amount is equal to allocated amount for Payment Detail Id:"
							+ paymtDtlId);
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
