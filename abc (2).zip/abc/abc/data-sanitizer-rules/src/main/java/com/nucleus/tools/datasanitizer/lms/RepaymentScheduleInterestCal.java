package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RepaymentScheduleInterestCal implements RuleExecutor {

      @Override
      public boolean shouldExecute(RootObject context) {
            // TODO Auto-generated method stub
            return true;
      }

      @Override
      public boolean execute(RootObject context, Logger logger) {
            List<Map<?, ?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
            List<String> logList = new ArrayList<String>();
            boolean resultFlag = true;
            if (repaymentDetails != null) {
                  Iterator<Map<?, ?>> it = repaymentDetails.iterator();
                  while (it.hasNext()) {
                        Map<String, String> mapValues = (Map<String, String>) it.next();
                        String Emi_Pemi_Flag = null;
                        BigDecimal Prin_Comp = new BigDecimal(0);
                        BigDecimal Interst_Rate = new BigDecimal(0);
                        BigDecimal Time = new BigDecimal(0);
                        BigDecimal Int_Comp = new BigDecimal(0);
                        BigDecimal CalInt = new BigDecimal(0);
                        BigDecimal instNumber = new BigDecimal(0);
                        for (Map.Entry entries : mapValues.entrySet()) {
                              if (("EMI_PEMI_FLAG").equals(entries.getKey()))
                                    Emi_Pemi_Flag = entries.getValue().toString();
                              if (("PRINCIPAL_COMPONENT").equals(entries.getKey()))
                                    Prin_Comp = ((BigDecimal) entries.getValue());
                              if (("EFFECTIVE_INTEREST_RATE").equals(entries.getKey()))
                                    Interst_Rate = ((BigDecimal) entries.getValue());
                              if (("INTEREST_DAYS").equals(entries.getKey()))
                                    Time = (BigDecimal) (entries.getValue());
                              if (("INTEREST_COMPONENT").equals(entries.getKey()))
                                    Int_Comp = ((BigDecimal) entries.getValue());
                              if (("INSTALMENT_NUMBER").equals(entries.getKey()))
                                    instNumber = ((BigDecimal) entries.getValue());
                        }
                        if (("E".equals(Emi_Pemi_Flag))) {

                              CalInt = (Prin_Comp.multiply(Interst_Rate).multiply(Time)).divide(new BigDecimal(100));

                              if ((CalInt).compareTo(Int_Comp) == 0 ) {

                                    resultFlag = true;
                              }

                              else {
                                    logList.add(
                                                "Calculated Interest and Interest Component mismatch for Installment # " + instNumber);
                                    resultFlag = false;
                              }

                        }
                  }

                  if (resultFlag)
                        logList.add("Calculated Interest and Interest Component matched for all the installments");

                  logger.setLog(logList);
                  return resultFlag;
            }

            return false;
      }

}