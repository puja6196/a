package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanRepaymentEffectiveIRNull implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> loanRepayment = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		boolean returnFlag=true;
		List<String> logList = new ArrayList<>();
	
		Timestamp date=new Timestamp(2015,06,30, 0, 0, 0, 0);
	
		if(loanRepayment!=null)
		{
			
			Iterator<Map<?, ?>> it = loanRepayment.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				BigDecimal effectiveIntRate = new BigDecimal(0);
				Date dueDate = null;
				BigDecimal repaymentId=new BigDecimal(0);
				
				for (Map.Entry entries : mapValues.entrySet()){
					if(("EFFECTIVE_INTEREST_RATE").equals(entries.getKey()))
						effectiveIntRate	 =((BigDecimal)  entries.getValue());
					if(("DUEDATE").equals(entries.getKey()))
						dueDate  = ((Date) entries.getValue());
					if(("ID").equals(entries.getKey())){
						repaymentId= (BigDecimal) entries.getValue();
					}	
					
				}
				if((effectiveIntRate==null)&&(dueDate.after(date))){
					logList.add("Lms_Repayschedule_Dtl Effective_Interest_Rate are null for Repayment Id"+repaymentId);
					returnFlag=false;
				}
				
				System.out.println(effectiveIntRate+"     "+dueDate+"     "+repaymentId);
				
			}

			if(returnFlag){
				
				
				logList.add("No data available in Loan Repayment");
			}
		
		}
		else
		{
			
			logList.add("No data available in Loan Repayment");
			returnFlag=false;
			
		}
		
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
