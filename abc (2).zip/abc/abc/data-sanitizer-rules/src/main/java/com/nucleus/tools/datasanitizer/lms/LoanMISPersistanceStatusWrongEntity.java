package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanMISPersistanceStatusWrongEntity implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		// TODO Auto-generated method stub
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<String>();
		Boolean resultFlag=true;
	
		           if(ctx!=null)
		                 {
		        		String id = (String) ctx.getValue("/loan_account/loan_mis_details/ENTITY_VERSION_ID", String.class);
		        		char status = (char) ctx.getValue("/loan_account/loan_mis_details/PERSISTENCE_STATUS", char.class);
			                 if(id==null)
			                {
				
			                   id="0";
				
			                }
			       if(status==' ')
			                {
				
				               status='1';
				
			                }
			
			       if(id=="0"||status!='0')
			                {
				               logList.add("Records in Loan MIS with wrong persistance status or wrong entity version");
				               return resultFlag=false;
				
			                }
			      
			       logger.setLog(logList);
					return resultFlag;	
		                 }
		     return false;
	}		

		

	
		
		
	

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
