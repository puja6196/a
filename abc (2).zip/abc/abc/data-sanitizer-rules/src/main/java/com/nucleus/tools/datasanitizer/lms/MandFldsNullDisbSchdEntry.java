package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class MandFldsNullDisbSchdEntry implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{
		List<Map<?,?>> disbSchEntryDtl = MVEL.eval("loan_account.?sub_loan_details.?disbursal_details.?disb_sch_entry_details", context, List.class);
		List<String> logList = new ArrayList<>();
		boolean resultFlag = true;
		if(disbSchEntryDtl != null)
		{
		
		Iterator<Map<?, ?>> it = disbSchEntryDtl.iterator();
		while (it.hasNext())
		{
			Map<String,String> mapValues = (Map<String, String>) it.next();
		
		    String disbType=null;
		    String disbEntryStatus=null;
		    String disbVerdict=null;
		    BigDecimal disbId=new BigDecimal(0);
		  
		    for (Map.Entry entries : mapValues.entrySet())
		    {
				if(("BT_DISBURSAL_TYPE").equals(entries.getKey()))
					disbType	 =(String)entries.getValue().toString();
					if(("DISBURSAL_ENTRY_STATUS").equals(entries.getKey()))
						disbEntryStatus  = (String) entries.getValue().toString();
					if(("DISBURSAL_VERDICT").equals(entries.getKey()))
						disbVerdict = (String)  entries.getValue().toString();
					if(("ID").equals(entries.getKey()))
						disbId = (BigDecimal)  entries.getValue();
					
			}
		    if(disbType==null)
		    {
		    	logList.add("BT DISBURSAL TYPE is null for Disbursal Id:"+disbId);
		    	resultFlag=false;
		    
		    }
		    if(disbEntryStatus==null)
		    {
		    	logList.add("DISBURSAL ENTRY STATUS is null for Disbursal Id:"+disbId);
		    	resultFlag=false;
		    
		    }
		    if(disbVerdict==null)
		    {
		    	logList.add("DISBURSAL VERDICT is null for Disbursal Id:"+disbId);
		    	resultFlag=false;
		    
		    }
		    }
		if(resultFlag)
		{
			logList.add("Mandatory fields are not null in DISBURSAL_SCHEDULE_ENTRY Table.");
		}
		}
		else
		{
			logList.add("No record available in Disbursal Schedule Entry Details.");
			resultFlag=false;
			
			
			
		}
		    
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject logger) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
