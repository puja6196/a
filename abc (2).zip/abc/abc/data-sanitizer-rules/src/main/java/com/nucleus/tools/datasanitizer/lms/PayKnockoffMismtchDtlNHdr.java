package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class PayKnockoffMismtchDtlNHdr implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{
		List<Map<?, ?>> knockoffDtls = MVEL.eval("loan_account.?knockoff_details", context, List.class);
		List<Map<?, ?>> knockoffHdr = MVEL.eval("loan_account.?knockoff_hdr", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean returnFlag = true;
		BigDecimal knockoffDtlsAmt=new BigDecimal(0);
		BigDecimal	knockoffHdrAmt=new BigDecimal(0);
	    BigDecimal	knockOffHdrId=new BigDecimal(0);
		String receivablePayFlag=null;
		String mcStatus=null;
		BigDecimal knockoffDtlsId=new BigDecimal(0);
		BigDecimal knockoffSumTemp=new BigDecimal(0);
		List <BigDecimal>l2=new ArrayList<>();
		
		
		if (knockoffDtls != null && knockoffHdr != null) {
			Iterator<Map<?, ?>> knockoffDtlsIt = knockoffDtls.iterator();
			while (knockoffDtlsIt.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) knockoffDtlsIt.next();
				for (Map.Entry entries : mapValues.entrySet())  {
					if (("KNOCKOFF_AMOUNT").equals(entries.getKey()))
						knockoffDtlsAmt = (BigDecimal) entries.getValue();
					if (("MC_STATUS").equals(entries.getKey()))
						mcStatus = (String) entries.getValue().toString();
					if (("ID").equals(entries.getKey()))
						knockoffDtlsId = (BigDecimal) entries.getValue();
					
					
				}
				l2.add(knockoffDtlsAmt);
				
			}
				
				Iterator<Map<?, ?>> knockoffHdrIt = knockoffHdr.iterator();
				while (knockoffHdrIt.hasNext()) {
					Map<String, String> mapValue = (Map<String, String>) knockoffHdrIt.next();
					for (Map.Entry entry : mapValue.entrySet()) {
						if (("KNOCKOFF_AMOUNT").equals(entry.getKey()))
							knockoffHdrAmt = (BigDecimal) entry.getValue();
						if (("KNOCKOFF_HDR_ID").equals(entry.getKey()))
							knockOffHdrId = (BigDecimal) entry.getValue();
						if (("RECEIVABLE_PAYABLE_FLAG").equals(entry.getKey()))
							receivablePayFlag = (String) entry.getValue().toString();
						

					}
					
					
					if((knockOffHdrId.compareTo(knockoffDtlsId)==0)&&(receivablePayFlag.equals("61099")))
					{
						
						knockoffSumTemp=knockoffSumTemp.add(knockoffSumTemp);
						
						
					}
					if((l2.contains(knockoffSumTemp))&&(mcStatus!="A"))
					{
						//do nothing
						
					}
					else
					{
						
						logList.add("Knockoff amount mismatch in LMS_KNOCKOFF_DTL and  LMS_KNOCKOFF_HDR Table.");
						returnFlag=false;
						
					}
			

					
				}
				if (returnFlag) 
				{
					logList.add("Knockoff amount no mismatch in LMS_KNOCKOFF_DTL and  LMS_KNOCKOFF_HDR Table.");
				}
			}
			
		else {
			logList.add("No record available either in KnockOff Details or KnockOff Header.");
			returnFlag = false;
		     }
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
