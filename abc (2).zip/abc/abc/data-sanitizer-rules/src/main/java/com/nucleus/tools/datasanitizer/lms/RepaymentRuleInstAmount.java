package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RepaymentRuleInstAmount implements RuleExecutor{

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean execute(RootObject context,Logger logger) {
		
		List<Map<?,?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		System.out.println(repaymentDetails);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if(repaymentDetails != null){
		
		Iterator<Map<?, ?>> it = repaymentDetails.iterator();
		while (it.hasNext()){
			Map<String,String> mapValues = (Map<String, String>) it.next();
			BigDecimal loanInstAmount = new BigDecimal(0);
			BigDecimal loanPrinComp = new BigDecimal(0);
			int instNumber = 0;
			BigDecimal loanIntComp = new BigDecimal(0);
			for (Map.Entry entries : mapValues.entrySet()){
				if(("INSTALMENT_AMOUNT").equals(entries.getKey()))
					loanInstAmount	 =((BigDecimal)  entries.getValue());
					if(("PRINCIPAL_COMPONENT").equals(entries.getKey()))
					loanPrinComp  = ((BigDecimal) entries.getValue());
					if(("INTEREST_COMPONENT").equals(entries.getKey()))
					loanIntComp = ((BigDecimal)  entries.getValue());
					if(("INSTALMENT_NUMBER").equals(entries.getKey()))
					instNumber = ((BigDecimal) entries.getValue()).intValue();
					
			}
			if ( (loanPrinComp.add(loanIntComp)).compareTo(loanInstAmount)==0){
				//do nothing	
				
		}
		else{
			logList.add("Principal + interest component is not equal to installment amount for Installment # "+instNumber + ",Installment Amount : "+loanInstAmount+",Principal Component : "+loanPrinComp+",Interest Component : "+loanIntComp+".");
			resultFlag=false;
		}
			
		} 
		
if(resultFlag)
	logList.add("Principal + interest component is equal to installment amount for all the installments.");
			logger.setLog(logList);
			return resultFlag;
		}
		
		return false;
	}

}
