package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanTerminationPayableAdjustedNull implements RuleExecutor 
{

	       @Override
	       public boolean execute(RootObject context, Logger logger) 
	       {
	    	   JXPathContext ctx = JXPathContext.newContext(context);
	  		   Boolean resultFlag=true; 
	           List<String> logList = new ArrayList<String>();
	           List<Map<?,?>> loanDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
	           if(ctx!=null)
	               {
	    	          BigDecimal id = (BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
	    	          String status = (String) ctx.getValue("/loan_account/STATUS", String.class);
	    	 
	    	           if(loanDetails!=null)
	    	              {
	    		 
	                         Iterator<Map<?, ?>> it = loanDetails.iterator();
	                           while (it.hasNext())
						
	                              {
		                                Map<String,String> mapValues = (Map<String, String>) it.next();
		
		                                BigDecimal loanId=new BigDecimal(0);
		                                BigDecimal payableAdjusted=new BigDecimal(0);
		
		                                  for (Map.Entry entries : mapValues.entrySet())
		                                     {
			                                     if(("LOANID").equals(entries.getKey()))
			                                        {
			                                	       loanId=(BigDecimal) entries.getValue();
				                                   
			                                        }
			                               
			                                     if(("PAYABLE_ADJUSTED").equals(entries.getKey()))
		                                            {
			                                	       payableAdjusted=(BigDecimal) entries.getValue();
			                                   
		                                            }
		                                     }
	    		   
	    		                         if(((id.compareTo(loanId))==0) &&(status=="A")&&((loanId==null)||(payableAdjusted==null)))
	    		                                   {
	    		    	                                resultFlag=false;
	    		                                        logList.add("Records where mandatory column PAYABLE_ADJUSTED are null."+id);
	    		     
	    		                                    }
	                              }
	    		                         if(resultFlag)
	    		                         {
	    		                        	 
	    		                        	 logList.add("Records where mandatory column PAYABLE_ADJUSTED are not null.");
	    		                        	 
	    		                        	 
	    		                        	 
	    		                         }
	    		     
	    		                    
	                              }
	    	           else
	    	           {
	    	        	   
	    	        	   logList.add("No record found in loanDetails.");
	    	        	   resultFlag=false;
	    	        	   
	    	        	   
	    	           }
	    		 
	    	        }
	           else
	           {
	        	   
	        	  logList.add("No record found.");
	        	  resultFlag=false;
	        	   
	           }
	    	
	     
	       logger.setLog(logList);
	    	return resultFlag;
	  
	
}

	@Override
	public boolean shouldExecute(RootObject context) 
	{
	
		return true;
	}

}
