package com.nucleus.tools.datasanitizer.lms;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAdvcPrincplNInttGrtrThnZero implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	    {
	
		      Boolean resultFlag=true;
		      List<String> logList = new ArrayList<String>();
	     	  List<Map<?,?>> adviceDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
System.out.println(adviceDtl);
		       if(adviceDtl!=null)
		          {
			         Iterator<Map<?, ?>> it = adviceDtl.iterator();
			           while (it.hasNext())
			            {
				          Map<String,String> mapValues = (Map<String, String>) it.next();				
				          BigDecimal chargeCode=new BigDecimal(0);
				          BigDecimal prinCompRecvd=new BigDecimal(0);
				          BigDecimal intCompRecvd=new BigDecimal(0);
				          String advDtlId=null;
				         System.out.println("helllooooooooooooooo");
				    
				               for (Map.Entry entries : mapValues.entrySet())
				                  {
					                   if(("ALLOCATEDAMT").equals(entries.getKey()))
					                       {
					        	              chargeCode=(BigDecimal) entries.getValue();
						          
						                   }
					                   if(("PRINCOMP_RECEIVED").equals(entries.getKey()))
					                       {
					        	               prinCompRecvd=(BigDecimal) entries.getValue();
						          
						                   }
					                   if(("INTCOMP_RECEIVED").equals(entries.getKey()))
					                       {
					        	               intCompRecvd=(BigDecimal) entries.getValue();
						          
						                   }
					                   if(("ID").equals(entries.getKey()))
				                       {
					                	   advDtlId=(String) entries.getValue().toString();
					          
					                   }
					                   System.out.println(chargeCode+"  "+prinCompRecvd+"   "+intCompRecvd+"  "+advDtlId);
					                   
				                  }
					                   if(chargeCode.compareTo(new BigDecimal(9))==0)
					                   {
					                	   
					                	   
					                   }
					                   else   
					                       {
					                	   if((prinCompRecvd.compareTo(BigDecimal.ZERO)>0)||(intCompRecvd.compareTo(BigDecimal.ZERO))==1)
					        	                resultFlag=false;
					        	                logList.add("Principal Component received or Interest Component received is greater than zero for Charge other than 9 for Advice Detail Id:"+advDtlId);
					           
					                        }
					                 
			            }
					                  if(resultFlag)
					                   {
					                	  
					                	  logList.add("Principal Component received or Interest Component received is not greater than zero for Charge other than 9. ");
					                	
					                   }
				                 }
				               
			            
		       else
		       {
		    	   
		    	   logList.add("No record found in Advice Details.");
		    	   resultFlag=false;
		    	   
		    	   
		       }
		         
				       logger.setLog(logList);
				       return resultFlag;
				       
				       
	
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
