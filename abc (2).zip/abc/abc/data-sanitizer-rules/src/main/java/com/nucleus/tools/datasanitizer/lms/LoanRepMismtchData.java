package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanRepMismtchData implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{    JXPathContext ctx = JXPathContext.newContext(context);
		 boolean returnFlag=true;
			
         List<String> logList = new ArrayList<String>();

         List<Map<?,?>> loanRepayment = MVEL.eval("loan_account.?loan_repayment", context, List.class);
         List<Map<?,?>> adviceDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
         BigDecimal accntDtlId = (BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
         if(loanRepayment!=null)
         {
				
            Iterator<Map<?, ?>> it = loanRepayment.iterator();
            while (it.hasNext())
					
               {
	                  Map<String,String> mapValues = (Map<String, String>) it.next();
	
	                 BigDecimal loanId=new BigDecimal(0);
	                 String emiPemiFlag=null;
	                 String billedFlag=null;
	                 String advancePrepayFlag=null;
	                 BigDecimal repaymntId=new BigDecimal(0);
	                 BigDecimal instlmntAmnt=new BigDecimal(0);
	                 BigDecimal princplComponent=new BigDecimal(0);
	                 BigDecimal interestComponent=new BigDecimal(0);
	                 BigDecimal advDtlLoanId=new BigDecimal(0);
	                 BigDecimal chargeCode=new BigDecimal(0);
	                 BigDecimal chargeCodeTemp=new BigDecimal(9);
	                 BigDecimal transId=new BigDecimal(0);
	                 BigDecimal receivablePayAmt =new BigDecimal(0);
	                 BigDecimal principalComponent=new BigDecimal(0);
	                 BigDecimal advcIntComponent=new BigDecimal(0);
	                 String adviceStatus=null;
	                   
	                 
	                 
	
	                      for (Map.Entry entries : mapValues.entrySet())
	                            {
		                          if(("LOANID").equals(entries.getKey()))
		                                 {
		                        	  loanId=(BigDecimal) entries.getValue();
			
		                                 }
		                          if(("EMI_PEMI_FLAG").equals(entries.getKey()))
	                                 {
		                        	  emiPemiFlag=(String) entries.getValue().toString();
		
	                                 }
		                          if(("BILLED_FLAG").equals(entries.getKey()))
	                                 {
		                        	  billedFlag=(String) entries.getValue().toString();
		
	                                 }
		                          if(("ADVANCE_PREPAY_FLAG").equals(entries.getKey()))
	                                 {
		                        	  advancePrepayFlag=(String) entries.getValue().toString();
		
	                                 }
		                          if(("ID").equals(entries.getKey()))
	                                 {
		                        	  repaymntId=(BigDecimal) entries.getValue();
		
	                                 }
		                    
		                          if(("INSTALMENT_AMOUNT").equals(entries.getKey()))
	                                 {
		                        	  instlmntAmnt=(BigDecimal) entries.getValue();
		
	                                 }
		                          if(("PRINCIPAL_COMPONENT").equals(entries.getKey()))
	                                 {
		                        	  princplComponent=(BigDecimal) entries.getValue();
		
	                                 }
		                          if(("INTEREST_COMPONENT").equals(entries.getKey()))
	                                 {
		                        	  interestComponent=(BigDecimal) entries.getValue();
		
	                                 }
		                          if(("advice_details").equals(entries.getKey()))
                                     adviceDtl=(List<Map<?, ?>>) entries.getValue();
                                     Iterator<Map<?, ?>> itr = adviceDtl.iterator();
         							while (itr.hasNext()) 
                                                                         {
         								Map<String, String> mapValue = (Map<String, String>) itr.next();
         								for (Map.Entry entry : mapValue.entrySet()){
         									
             							if(("LOANID").equals(entry.getKey()))
             									advDtlLoanId=(BigDecimal)entry.getValue();
         								if(("CHARGECODE").equals(entry.getKey()))
         									chargeCode=(BigDecimal)entry.getValue();
         								if(("TRANSACTIONID").equals(entry.getKey()))
         									transId=(BigDecimal)entry.getValue();
         								if(("RECEIVABLE_PAYABLE_AMT").equals(entry.getKey()))
         									receivablePayAmt=(BigDecimal)entry.getValue();
         								
         								if(("PRINCIPAL_COMPONENT").equals(entry.getKey()))
         									principalComponent=(BigDecimal)entry.getValue();
         								if(("INTEREST_COMPONENT").equals(entry.getKey()))
         									advcIntComponent=(BigDecimal)entry.getValue();
         								if(("STATUS").equals(entry.getKey()))
         									adviceStatus=(String)entry.getValue();
         								}
         								
                                                                         }	
	                            }
         								
         								if(((loanId.compareTo(accntDtlId)==0)&&(adviceStatus=="A"))&&
         								((loanId.compareTo(advDtlLoanId)==0)&&
         										(chargeCode.compareTo(chargeCodeTemp)==0)&&(emiPemiFlag=="E")&&
         										(billedFlag=="Y")&&(advancePrepayFlag=="N"))&&
         										((loanId.compareTo(transId))==0)&&((instlmntAmnt.compareTo(receivablePayAmt)!=0)||
         												(princplComponent.compareTo(principalComponent)!=0)||(interestComponent.compareTo(advcIntComponent)!=0)))
         								{
         									
         									
         									logList.add("Billed installments having mismatch in Instalment_Amount,Principal_Component and Interest_Component in LMS_REPAYSCHEDULE_DTL AND LMS_RECEIVABLEPAYABLE_DTL Table for Loan Id:"+advDtlLoanId);
         									returnFlag=false;
         									
         									
         									
         								}

	


               }
         								
         								
         								
         								
         								
         								
         								
         								
         								
         									
	                 if(returnFlag)
	                 {
	                	 
	                	 logList.add("Billed installments having match in Instalment_Amount,Principal_Component and Interest_Component in LMS_REPAYSCHEDULE_DTL AND LMS_RECEIVABLEPAYABLE_DTL Table.");	 
	                	 
	                	 
	                	 
	                 }
                                     
		                          
	                                         
		                          
	                 }
         else
         {
        	 
        	 logList.add("No record available in Loan Repayment.");  	 
        	 returnFlag=false;
         }
		                          
		                          
		                          
		                          
		 logger.setLog(logList);
		 return returnFlag;
		                          
		                          
		                          
		                          
	                            

        

		
	}

	@Override
	public boolean shouldExecute(RootObject context) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
