package com.nucleus.tools.datasanitizer.lms;

	import java.math.BigDecimal;
	import java.util.ArrayList;
	import java.util.Date;
	import java.util.Iterator;
	import java.util.List;
	import java.util.Map;

	import org.apache.commons.jxpath.JXPathContext;
	import org.mvel2.MVEL;

	import com.nucleus.tools.datasanitizer.model.RootObject;
	import com.nucleus.tools.datasanitizer.rules.Logger;
	import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

	public class PrabhashDisbursalDetails implements RuleExecutor
	{

		@Override
		public boolean execute(RootObject context, Logger logger) 
		{
			
			JXPathContext ctx = JXPathContext.newContext(context);
			List<String> logList = new ArrayList<String>();
			boolean returnFlag=true;
			List<Map<?,?>> disbursaldetails = MVEL.eval("loan_account.?disbursal_details", context, List.class);
			if(disbursaldetails!=null)
			{
				
				Iterator<Map<?,?>> itr= disbursaldetails.iterator();
				while(itr.hasNext())
				{
					Map<String,String> mValues= (Map<String, String>) itr.next();
					Integer id= new Integer(0);  
					String loanAccountNum= null;	
					Integer currencyMstId= new Integer(0);	
					BigDecimal loanDisbursalAmount = new BigDecimal(0);    
					Date disbursalDate = null; 	
					Integer disbursalNo = new Integer(0); 	
					BigDecimal disbursalRate= new BigDecimal(0);	
					Date disbursalTxnDate = null;		
					Integer loanId = new Integer(0);		
					String startInstlmntRecoverty=null;	
					String disbursalStatus= null; 
					String txnType= null;		
					for(Map.Entry entry:mValues.entrySet())
	                     {
						      if(("LOAN_ACCOUNT_NO").equals(entry.getKey()))
							  loanAccountNum=entry.getValue().toString();
						      if(("CURRENCY_MST_ID").equals(entry.getKey()))
							  currencyMstId=(Integer) entry.getValue();
						      if(("DISBURSAL_AMT").equals(entry.getKey()))
							  loanDisbursalAmount=(BigDecimal) entry.getValue();
						      if(("DISBURSAL_DATE").equals(entry.getKey()))
							  disbursalDate=(Date) entry.getValue();
						      if(("DISBURSAL_NO").equals(entry.getKey()))
							  disbursalNo=(Integer) entry.getValue();
						      if(("DISBURSAL_RATE").equals(entry.getKey()))
							  disbursalRate=(BigDecimal) entry.getValue();
						      if(("DISBURSAL_TXN_DATE").equals(entry.getKey()))
							  disbursalTxnDate=(Date) entry.getValue();
						      if(("START_INSTALLMENT_RECOVERY").equals(entry.getKey()))
							  startInstlmntRecoverty=entry.getValue().toString();
						      if(("DISBURSAL_STATUS").equals(entry.getKey()))
							  disbursalStatus=entry.getValue().toString();
						      if(("TRANSACTION_TYPE").equals(entry.getKey()))
							  txnType=entry.getValue().toString();
						      if(("ID").equals(entry.getKey()))
							  id=(Integer) entry.getValue();
					}
					if("A".equals(disbursalStatus))
					{
						if(loanAccountNum.isEmpty()){
							logList.add("Loan Account Number is empty for loan id: "+id);
							returnFlag=false;
						}
						if(currencyMstId==null){
							logList.add("Currency Mst Id is empty for loan id: "+id);
							returnFlag=false;
						}
						if(loanDisbursalAmount==null){
							logList.add("Loan Disbursal Amount is empty for loan id: "+id);
							returnFlag=false;
						}
						if(disbursalDate==null){
							logList.add("Loan Disbursal Date is empty for loan id: "+id);
							returnFlag=false;
						}
						if(disbursalNo==null){
							logList.add("Loan Disbursal Number is empty for loan id: "+id);
							returnFlag=false;
						}
						if(disbursalRate==null){
							logList.add("Loan Disbursal Rate is empty for loan id: "+id);
							returnFlag=false;
						}
						if(disbursalTxnDate==null){
							logList.add("Disbursal Txn Date is empty for loan id: "+id);
							returnFlag=false;
						}
						if(startInstlmntRecoverty==null){
							logList.add("Start Installment Recovery is empty for loan id: "+id);
							returnFlag=false;
						}
						if(disbursalStatus==null){
							logList.add("Disbursal Status is empty for loan id: "+id);
							returnFlag=false;
						}
						if(txnType==null){
							logList.add("Transaction Type is empty for loan id: "+id);
							returnFlag=false;
						}
					}
					
				}
				if(returnFlag)
				{
					logList.add("No mandatory field is empty for loan id: ");
				}
				
			}
			else
			{
				
				logList.add("Disbursal Details are not available.");
				
			}
			logger.setLog(logList);
			return returnFlag;
		}

		@Override
		public boolean shouldExecute(RootObject context) {

			return true;
		}

	}



