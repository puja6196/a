package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TDS863 implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{

		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<>();
		boolean resultFlag = true;
		Date tdseffDate = (Date) ctx.getValue("/loan_account/loan_additional_info/TDS_EFFECTIVE_DATE", Date.class);
		
		Date effTdsRateDate = (Date) ctx.getValue("/loan_account/loan_additional_info/EFFECTIVE_TDS_RATE_DATE", Date.class);
	
		BigDecimal addtnlInfoLoanId = (BigDecimal) ctx.getValue("/loan_account/loan_additional_info/LOANID", BigDecimal.class);
		BigDecimal lmsAccntId = (BigDecimal) ctx.getValue("/loan_account/ID", BigDecimal.class);
		BigDecimal lmsTdsPolicyId = (BigDecimal) ctx.getValue("/loan_account/TDS_POLICY_ID", BigDecimal.class);
		if((lmsAccntId.compareTo(addtnlInfoLoanId)==0)&&(lmsTdsPolicyId!=null))
		{
		if((tdseffDate==null)&&(effTdsRateDate==null))
		{
			logList.add("DS_EFFECTIVE_DATE and EFFECTIVE_TDS_RATE_DATE  is null in Loan Additional info.");
			resultFlag=false;
		}
		}
		if(resultFlag)
		{
			
		logList.add("DS_EFFECTIVE_DATE and EFFECTIVE_TDS_RATE_DATE  is not null in Loan Additional info.");
			
		}
		
		
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
