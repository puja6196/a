

	package com.nucleus.tools.datasanitizer.lms;

	import java.math.BigDecimal;
	import java.util.ArrayList;
	import java.util.Iterator;
	import java.util.List;
	import java.util.Map;

	import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;
public class Test implements RuleExecutor
{
		@Override
		public boolean execute(RootObject context, Logger logger)
		{List arr=new ArrayList<>();
			Boolean resultFlag=true;
			BigDecimal count=new BigDecimal(0);
			 List<Map<?,?>> termDtlDetails = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
			 
			 
			 List<Map<?,?>> termHdrDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
			 List<String> logList = new ArrayList<>();
			 if(termHdrDetails!=null)
				{
				 Iterator<Map<?, ?>> itr = termHdrDetails.iterator();
	          while (itr.hasNext())
						
	             {
		                  Map<String,String> mapValues = (Map<String, String>) itr.next();
		
		                 BigDecimal terminationId=new BigDecimal(0);
		                 
		             	BigDecimal terHdrId = new BigDecimal(0) ;
		
		                      for (Map.Entry entries : mapValues.entrySet())
		                            {
			                          if(("ID").equals(entries.getKey()))
			                                 {
			                        	 
			                     	 terHdrId   = (BigDecimal) entries.getValue();
			                        	  
			                                 }
		                            }
		                      arr.add(terHdrId);
	             }
			                         
			                          Iterator<Map<?, ?>> it = termDtlDetails.iterator();
	                                           while (it.hasNext()) 
	                                              {
	                                                 Map<String, String> mapValue = (Map<String, String>) it.next();
	                                           

	                                         		for (Map.Entry entrie : mapValue.entrySet()) 
	                                         		     {
	                                         			if (("TERMINATIONID").equals(entrie.getKey()))
	                                         			{
	                                         				
	                                         				terminationId = (BigDecimal) entrie.getValue();
	                                         				
	                                         		     } 
	                                         	
	                                         		     }
	                                         		
	                                              }
	                                         		 if(terminationId.compareTo(terHdrId)==0)
	                                                  {
	                        	                    //do nothing
	                                                  }
	                                         		 else
	                                         		 {     

	                                         			  logList.add("Data which are not in  LMS_TERMINATION_DTL table for Termination Id:"+terminationId);
	                                              		
	                                                  	  resultFlag=false; 
	                                                  	  break;
	                                         			
	                                         			 
	                                         			 
	                                         		 }
	                                         		
	                                         		count=count.add(BigDecimal.ONE);
	                                         		
	                                               }
	                                           
		                            }
		                     
	             }

		                      if(resultFlag)
	                       {
	                     	 logList.add("No data available in Termination Details.");
	                     }
				}
		else
		{
			logList.add("No record found in Termination Details");
			resultFlag=false;
		}
		
	 logger.setLog(logList);
	 return resultFlag;
		                         
		}

		@Override
		public boolean shouldExecute(RootObject context) {

			return true;
		}

	

	}



