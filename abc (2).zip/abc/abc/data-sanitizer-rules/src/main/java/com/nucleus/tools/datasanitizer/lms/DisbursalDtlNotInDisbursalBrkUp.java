package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalDtlNotInDisbursalBrkUp implements RuleExecutor {
	@Override
	public boolean execute(RootObject context, Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		String status = (String) ctx.getValue("/loan_account/STATUS", String.class);
		List<Map<?, ?>> lmsDistbursalDetails = MVEL.eval("loan_account.?disbursal_details", context, List.class);
		List<Map<?, ?>> lmsDistbursalBreakupDetails = MVEL
				.eval("loan_account.?disbursal_details.?disbursal_details_breakup", context, List.class);

		List<String> logList = new ArrayList<>();
		boolean resultFlag = true;
		if (lmsDistbursalBreakupDetails != null && lmsDistbursalDetails != null) {
			Iterator<Map<?, ?>> disbursalDtlItr = lmsDistbursalDetails.iterator();
			BigDecimal disbursalAmt = new BigDecimal(0);
			BigDecimal vapId = new BigDecimal(0);
			BigDecimal disbursalId = new BigDecimal(0);
			String disbursalStatus = null;
			while (disbursalDtlItr.hasNext()) {
				Map<String, String> mapValue = (Map<String, String>) disbursalDtlItr.next();
				for (Map.Entry entries : mapValue.entrySet()) {
					try {
						if (("DISBURSAL_STATUS").equals(entries.getKey()))
							disbursalStatus = (String) entries.getValue();
						if (("DISBURSAL_AMT").equals(entries.getKey()))
							disbursalAmt = (BigDecimal) entries.getValue();
						if (("ID").equals(entries.getKey()))
							disbursalId = (BigDecimal) entries.getValue();
						if (("VAPID").equals(entries.getKey()))
							vapId = (BigDecimal) entries.getValue();
						if(vapId==null)
							vapId=BigDecimal.ZERO;
						if (disbursalAmt == null)
							disbursalAmt = BigDecimal.ZERO;
					} catch (Exception e) {
						logList.add("Exception occured while retrieving data from Disbursal details");
					}
				}
				Iterator<Map<?, ?>> breakUpItr = lmsDistbursalBreakupDetails.iterator();
				BigDecimal disbursalBrkUpAmt = new BigDecimal(0);
				BigDecimal sumDisbursalBrkUpAmt = new BigDecimal(0);
				BigDecimal brkUpDisbursalId = new BigDecimal(0);
				BigDecimal brkUpId = new BigDecimal(0);
				String disbursalBrkUpStatus = null;
				while (breakUpItr.hasNext()) {
					Map<String, String> mapValues = (Map<String, String>) breakUpItr.next();
					for (Map.Entry entries : mapValues.entrySet()) {
						try {
							if (("ID").equals(entries.getKey()))
								brkUpId = (BigDecimal) entries.getValue();
							if (("DISBURSAL_STATUS").equals(entries.getKey()))
								disbursalBrkUpStatus = (String) entries.getValue();
							if (("DISBURSAL_AMT").equals(entries.getKey()))
								disbursalBrkUpAmt = (BigDecimal) entries.getValue();
							if (("Disbursal_Id").equals(entries.getKey()))
								brkUpDisbursalId = (BigDecimal) entries.getValue();
						} catch (Exception e) {
							logList.add("Exception occured while Retrieving data from DisbursalBreakUp Detail");
						}
					}
					if (("A".equals(disbursalBrkUpStatus)) && (disbursalId.compareTo(brkUpDisbursalId) == 0)) {
						sumDisbursalBrkUpAmt = sumDisbursalBrkUpAmt.add(disbursalBrkUpAmt);
					}
					if (sumDisbursalBrkUpAmt == null)
						sumDisbursalBrkUpAmt = BigDecimal.ZERO;
					
							if ((!(disbursalAmt.compareTo(sumDisbursalBrkUpAmt) == 0)) && ("A".equals(disbursalStatus))
									&& ("A".equals(status))&&(brkUpDisbursalId.compareTo(disbursalId) == 0)&&(vapId.compareTo(BigDecimal.ZERO) == 0)) {
								logList.add(
										"lms Disbursal Details does  exist in Disbursal BreakUp Detail for Disbursal Breakup Id: "
												+ brkUpId);
								resultFlag = false;
								break;
							}
					
				}
			}
		} else {
			logList.add("Disbursal Details are not available.");
			resultFlag = false;
		}

		if (resultFlag)
			logList.add("Disbursal Breakup Details are not available for disbursals.");
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
