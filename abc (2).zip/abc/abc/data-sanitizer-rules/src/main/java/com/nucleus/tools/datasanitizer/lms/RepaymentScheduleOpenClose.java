package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RepaymentScheduleOpenClose implements RuleExecutor{

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		
		boolean resultFlag = true;
		if(repaymentDetails != null){
		
		Iterator<Map<?, ?>> it = repaymentDetails.iterator();
		while (it.hasNext()){
			Map<String,String> mapValues = (Map<String, String>) it.next();
			BigDecimal balancePrin = new BigDecimal(0);
			BigDecimal loanPrinComp = new BigDecimal(0);
			int instNumber = 0;
			BigDecimal closingPrin = new BigDecimal(0);
			for (Map.Entry entries : mapValues.entrySet()){
				if(("BALANCE_PRINCIPAL").equals(entries.getKey()))
					balancePrin	 =((BigDecimal)  entries.getValue());
					if(("PRINCIPAL_COMPONENT").equals(entries.getKey()))
					loanPrinComp  = ((BigDecimal) entries.getValue());
					if(("CLOSING_PRINCIPAL").equals(entries.getKey()))
						closingPrin = ((BigDecimal)  entries.getValue());
					if(("INSTALMENT_NUMBER").equals(entries.getKey()))
					instNumber = ((BigDecimal) entries.getValue()).intValue();
					
					
			}
			if ( (balancePrin.subtract(loanPrinComp)).compareTo(closingPrin)==0){
				//do nothing
				
		}
		else{
			logList.add("Opening Principal – Principal Component != Closing principal for Installment # "+instNumber+",BALANCE_PRINCIPAL : "+balancePrin+",PRINCIPAL_COMPONENT : "+loanPrinComp+",CLOSING_PRINCIPAL : "+closingPrin+".");
			resultFlag=false;
		}
		} 
		
if (resultFlag)
	logList.add("Opening Principal – Principal Component = Closing principal for all the installments.");

			logger.setLog(logList);
			return resultFlag;
		}
		
		return false;
	}

}
