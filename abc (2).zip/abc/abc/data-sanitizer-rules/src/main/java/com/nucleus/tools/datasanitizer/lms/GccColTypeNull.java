package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class GccColTypeNull implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		 JXPathContext ctx = JXPathContext.newContext(context);
	     Boolean resultFlag=true; 
	     List<String> logList = new ArrayList<String>();
		BigDecimal billedInterestAmt = (BigDecimal) ctx.getValue("/loan_account/GLOBAL_COLLATERAL_ENTITY_FIS", BigDecimal.class);
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
