package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RepaymentRulePrinCompLoanAmount implements RuleExecutor{

	@Override
	public boolean shouldExecute(RootObject context) {
		return true;
	}

	@Override
	public boolean execute(RootObject context, Logger logger) {
		
		JXPathContext ctx = JXPathContext.newContext(context);
		String disbStatusId = (String) ctx.getValue("/loan_account/DISBURSAL_STATUS_ID", String.class);
		Long loanAmount = (Long) ctx.getValue("/loan_account/LOAN_AMOUNT", Long.class);
		List<String> logList = new ArrayList<String>();
		List<Map<?,?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		boolean returnFlag=true;
	if ("2860".equals(disbStatusId)){
		
	      
          if(repaymentDetails != null){
                int sum = repaymentDetails.stream().filter(ddb -> ((BigDecimal)ddb.get("VAPID")).compareTo(BigDecimal.ZERO)==0 ).mapToInt(ddb -> ((BigDecimal)ddb.get("PRINCIPAL_COMPONENT")).intValue()).sum();
                if (sum == loanAmount){
                		returnFlag=true;
                		logList.add("Loan Amount is equal to sum of principal component in the Repayment Schedule.");
                }
                else{
                	returnFlag=false;
                	logList.add("Loan Amount is not equal to sum of principal component in the Repayment Schedule. Loan Amount : "+loanAmount+",Sum of principal components : "+sum+".");
                }
          }else{
        	  returnFlag = false;
        	  logList.add("Repayment Schedule does not exists for this loan");
          }

		
	}else
	{
		returnFlag=true;
		logList.add("This Loan is not fully disbursed, hence this rule is not applicable.");
	}
		
	logger.setLog(logList);
		return returnFlag;
	
		
	}
	


}
