package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class SidTrial implements RuleExecutor {

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<String> logList = new ArrayList<>();
		 List<Map<?,?>> termHdrDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		 List<Map<?,?>> termDtlDetails = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
		 Boolean resultFlag=true;
			
			BigDecimal hdrId=new BigDecimal(0);
		
			 if(termHdrDetails!=null)
				{
				 Iterator<Map<?, ?>> itr = termHdrDetails.iterator();
				 List l=new ArrayList<>();
	          while (itr.hasNext())
						
	             {
		                  Map<String,String> mapValues = (Map<String, String>) itr.next();
		                  for (Map.Entry entries : mapValues.entrySet()){
		                	  if(("ID").equals(entries.getKey()))
		                		  hdrId=(BigDecimal) entries.getValue(); 
		                         
		                  }
		          l.add(hdrId);        
	             }
	          
	          Iterator<Map<?, ?>> dtlItr = termDtlDetails.iterator(); 
	          BigDecimal terminationId=new BigDecimal(0);
	          BigDecimal terDtlId=new BigDecimal(0);
	          while (dtlItr.hasNext())
					
	             {
		                  Map<String,String> mapValues = (Map<String, String>) dtlItr.next();
		                  for (Map.Entry entries : mapValues.entrySet()){
		                	  if (("TERMINATIONID").equals(entries.getKey()))
                   			{
                   				
                   				terminationId = (BigDecimal) entries.getValue();
                   				
                   		     } 
		                	  
		                	  if (("ID").equals(entries.getKey()))
	                   			{
	                   				
	                   				terDtlId = (BigDecimal) entries.getValue();
	                   				
	                   		     } 
			                	  
		                
		                  }
		                  
		                  if((l.contains(terminationId)))
		                  {
		                	  
		                  }
		                  else
		                  {
		                	  logList.add("Records which are not in  LMS_TERMINATION_DTL table having Termination Detail Id:."+terDtlId);
		                	  resultFlag=false;
		                	
		                  }
		                  
		                  
	             }
	          if(resultFlag)
	          {
	        	  
	        	  logList.add("Records  are available in  LMS_TERMINATION_DTL table."); 
	        	  
	        	  
	          }
	          
	     
				}
			 else
			 {
				 
				 logList.add("No record available in Termination Header Details.");
				  resultFlag=false;
				 
			 }
			 
			 
		logger.setLog(logList);	 
		return resultFlag;
	
				
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
