package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class CASAppPersonInfCantNull implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{
		
		List<Map<?,?>> personInfoDtls = MVEL.eval("loan_account.?cas_loan_app_details.?party_details.?person_info_details", context, List.class);
		
		
		List<String> logList = new ArrayList<>();
		boolean resultFlag = true;
		if(personInfoDtls != null)
		{
		
		Iterator<Map<?, ?>> it = personInfoDtls.iterator();
		while (it.hasNext())
		{
			Map<String,String> mapValues = (Map<String, String>) it.next();
		    Date personInfoDob=null;
		    String personGender=null;
		    String country=null;
		    BigDecimal persongInfoId=new BigDecimal(0);
		    for (Map.Entry entries : mapValues.entrySet())
		    {
				if(("DATE_OF_BIRTH").equals(entries.getKey()))
					personInfoDob	 =(Date)entries.getValue();
					if(("BUSINESSPARTNER_ID").equals(entries.getKey()))
						personGender  = (String) entries.getValue().toString();
					if(("SUBVENTION_ID").equals(entries.getKey()))
						country = (String)  entries.getValue().toString();
					if(("ID").equals(entries.getKey()))
						persongInfoId = (BigDecimal)  entries.getValue();
						
			}
		    if(personInfoDob==null)
		    {
		    	logList.add("DATE OF BIRTH is null for Person Info Id:"+persongInfoId);
		    	resultFlag=false;
		    
		    }
		    if(personGender==null)
		    {
		    	logList.add("GENDER is null for Person Info Id:"+persongInfoId);
		    	resultFlag=false;
		    
		    }
		    
		    	
		    	if(country==null)
		    {
		    	logList.add("COUNTRY is null for Person Info Id:"+persongInfoId);
		    	resultFlag=false;
		    
		    }
		    }
		if(resultFlag)
		{
			logList.add("DATE_OF_BIRTH,GENDER,COUNTRY in PERSON_INFO are null");
		}
		}
		else
		{
			logList.add("No record available in Person Info.");
			resultFlag=false;
			
			
			
		}
		    
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
