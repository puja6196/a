package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TDS860 implements RuleExecutor

{
	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		List<Map<?,?>> tdsTxnDtls = MVEL.eval("loan_account.?tds_txn_details", context, List.class);
		boolean returnFlag=true;
		List<String> logList = new ArrayList<>();
		if(tdsTxnDtls!=null)
		{
    	Iterator<Map<?, ?>> it = tdsTxnDtls.iterator();
			while (it.hasNext())
			{
				Map<String,String> mapValues = (Map<String, String>) it.next();
				String tdsTxnStatus = null;
				BigDecimal rejectMstId=new BigDecimal(0);
				BigDecimal tdsTxnId=new BigDecimal(0);
				
				for (Map.Entry entries : mapValues.entrySet())
				{
					if(("MC_STATUS").equals(entries.getKey()))
						tdsTxnStatus	 =(String)  entries.getValue().toString();
					if(("REJECT_REASON_MST_ID").equals(entries.getKey()))
						rejectMstId  = ((BigDecimal) entries.getValue());
					if(("ID").equals(entries.getKey()))
						tdsTxnId  = ((BigDecimal) entries.getValue());
				}
				if((tdsTxnStatus=="R")&&(rejectMstId==null))
				{
					logList.add("LMS_TDS_TXN_DTL where MC_STATUS is Rejected and Rejected reason is null for TDS Transaction Id:"+tdsTxnId);
				    returnFlag=false;
				}
				}
			if(returnFlag)
			{
				logList.add("LMS_TDS_TXN_DTL where MC_STATUS is not Rejected and Rejected reason is not null .");
			
			}
		}
		else
		{
			
			
			logList.add("No record available in TDS Transaction Details.");
			returnFlag=false;
		}
			logger.setLog(logList);
			return returnFlag;
		
	
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}
	}