package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManFldsNullLMSSubTxnDtl implements RuleExecutor 
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		List<Map<?, ?>> subvntnTranDtls = MVEL.eval("loan_account.?subvention_txn_details", context, List.class);

		boolean resultFlag = true;
		List<String> logList = new ArrayList<>();
		if (subvntnTranDtls != null) 
		{

			Iterator<Map<?, ?>> it = subvntnTranDtls.iterator();
			while (it.hasNext())
			{
				Map<String, String> mapValues = (Map<String, String>) it.next();
				BigDecimal bpTypeId = new BigDecimal(0);
				BigDecimal businessPartnerId = new BigDecimal(0);
				BigDecimal subventionId = new BigDecimal(0);
				Date subventionEndDate = null;
				BigDecimal subvntnTxnDtlId = new BigDecimal(0);

				String loanAccNo = null;
				BigDecimal loanId = new BigDecimal(0);
				Date subventionStrtDate = null;
				BigDecimal subventionBasis = new BigDecimal(0);

				BigDecimal subventionPercentage = new BigDecimal(0);
				String subventionType = null;
				String mcStatus = null;
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("BPTYPE_ID").equals(entries.getKey()))
						bpTypeId = ((BigDecimal) entries.getValue());
					if (("BUSINESSPARTNER_ID").equals(entries.getKey()))
						businessPartnerId = ((BigDecimal) entries.getValue());
					if (("SUBVENTION_ID").equals(entries.getKey()))
						subventionId = ((BigDecimal) entries.getValue());
					if (("SUBVENTION_END_DATE").equals(entries.getKey()))
						subventionEndDate = ((Date) entries.getValue());
					if (("ID").equals(entries.getKey()))
						subvntnTxnDtlId = ((BigDecimal) entries.getValue());
					if (("LOAN_ACCOUNT_NO").equals(entries.getKey()))
						loanAccNo = ((String) entries.getValue().toString());
					if (("LOANID").equals(entries.getKey()))
						loanId = ((BigDecimal) entries.getValue());
					if (("SUBVENTION_START_DATE").equals(entries.getKey()))
						subventionStrtDate = ((Date) entries.getValue());
					if (("SUBVENTION_BASIS").equals(entries.getKey()))
						subventionBasis = ((BigDecimal) entries.getValue());

					if (("SUBVENTION_PERCENTAGE").equals(entries.getKey()))
						subventionPercentage = ((BigDecimal) entries.getValue());
					if (("SUBVENTION_TYPE").equals(entries.getKey()))
						subventionType = ((String) entries.getValue().toString());
					if (("MC_STATUS").equals(entries.getKey()))
						mcStatus = ((String) entries.getValue().toString());

				}
				if (bpTypeId == null)
				{
					logList.add("BP Type Id is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (businessPartnerId == null)
				{
					logList.add("BUSINESSPARTNER ID is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (subventionBasis == null) 
				{
					logList.add("Subvention Basis is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (subventionEndDate == null)
				{
					logList.add("Subvention End Date is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (subventionId == null) 
				{
					logList.add("Subvention Basis is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (subventionPercentage == null) 
				{
					logList.add("Subvention Percentage is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (subventionStrtDate == null)
				{
					logList.add("Subvention Start Date is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (subventionType == null) 
				{

					logList.add("Subvention Type is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (mcStatus == null) 
				{

					logList.add("MC Status is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (loanAccNo == null) 
				{
					logList.add("Loan Account Number is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;
				}
				if (loanId == null) 
				{
					logList.add("Loan Id is null for Subvention Txn Id:" + subvntnTxnDtlId);
					resultFlag = false;

				}
			}
			if (resultFlag) 
			{

				logList.add(
						"BPTYPE ID,BUSINESSPARTNER ID,SUBVENTION ID,SUBVENTION END DATE,LOAN ACCOUNT NO,LOANID,SUBVENTION START DATE,SUBVENTION BASIS,SUBVENTION PERCENTAGE,SUBVENTION TYPE,MC STATUS are not null in Subvention Transaction Details.");
			}
		}
		else 
		{

			logList.add("No record available in Subvention Transaction Details.");
			resultFlag = false;
		}

		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) 
	{

		return true;
	}

}
