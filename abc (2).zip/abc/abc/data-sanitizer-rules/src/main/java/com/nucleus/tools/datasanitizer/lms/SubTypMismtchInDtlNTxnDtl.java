package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class SubTypMismtchInDtlNTxnDtl implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?, ?>> subventiondetails = MVEL.eval("loan_account.?subvention_details", context, List.class);
		List<Map<?, ?>> subventiontxndetails = MVEL.eval("loan_account.?subvention_txn_details", context, List.class);
		List<String> logList = new ArrayList<String>();
		List<BigDecimal> idtxn = new ArrayList<BigDecimal>();
		List<BigDecimal> subventiontxndtlval = new ArrayList<BigDecimal>();
	
		boolean returnFlag = true;
		BigDecimal subventionpercentagedtl = new BigDecimal(0);
		BigDecimal loanid = new BigDecimal(0);
		BigDecimal id = new BigDecimal(0);
		BigDecimal subventionpercentagetxndtl = new BigDecimal(0);
		BigDecimal idtxndtl = new BigDecimal(0);
		BigDecimal loanidtxn = new BigDecimal(0);
		BigDecimal subventionid = new BigDecimal(0);
		String mcstatus = null;
		BigDecimal idtxnmaxval = new BigDecimal(0);
	
		if (subventiondetails != null && subventiontxndetails != null) {
			Iterator<Map<?, ?>> subventiondetailsit = subventiondetails.iterator();
			while (subventiondetailsit.hasNext()) {
				Map<String, String> mapValues = (Map<String, String>) subventiondetailsit.next();
				for (Map.Entry entries : mapValues.entrySet()) {
					if (("SUBVENTION_PERCENTAGE").equals(entries.getKey()))
						subventionpercentagedtl = (BigDecimal) entries.getValue();
					if (("LOANID").equals(entries.getKey()))
						loanid = (BigDecimal) entries.getValue();
					if (("ID").equals(entries.getKey()))
						id = (BigDecimal) entries.getValue();
					
				}
				Iterator<Map<?, ?>> subventiontxndtlitr = subventiontxndetails.iterator();
				while (subventiontxndtlitr.hasNext()) {
					Map<String, String> mapValue = (Map<String, String>) subventiontxndtlitr.next();
					for (Map.Entry entry : mapValue.entrySet()) {
						if (("SUBVENTION_PERCENTAGE").equals(entry.getKey()))
							subventionpercentagetxndtl = (BigDecimal) entry.getValue();
						if (("ID").equals(entry.getKey()))
							idtxndtl = (BigDecimal) entry.getValue();
						if (("LOANID").equals(entry.getKey()))
							loanidtxn = (BigDecimal) entry.getValue();
						if (("SUBVENTION_ID").equals(entry.getKey()))
							subventionid = (BigDecimal) entry.getValue();
						if (("MC_STATUS").equals(entry.getKey()))
							mcstatus = entry.getValue().toString();

					}
					
			
					if (("A".equals(mcstatus)) && (id.compareTo(subventionid) == 0)
							&& (loanid.compareTo(loanidtxn) == 0)) {
						idtxn.add(idtxndtl);

						idtxnmaxval = Collections.max(idtxn);

					}

					if ((idtxndtl.compareTo(idtxnmaxval) == 0)) {
						subventiontxndtlval.add(subventionpercentagetxndtl);
					

					}

					if ((subventiontxndtlval.contains(subventionpercentagedtl))) {
						// do nothing

					} else {

						logList.add(
								"Subvention Percentage in Subvention Details is not equal to Subvention Precentage in Subvention Transaction Details for LoanId ="
										+ loanid);
						returnFlag = false;
					}
				}
			}
			if (returnFlag) {
				logList.add(
						"Subvention Percentage in Subvention Details is equal to Subvention Precentage in Subvention Transaction Details.");
			}
		} else {
			logList.add("Subvention Details and Subvention Transaction details are not avilable.");
			returnFlag = false;
		}
		logger.setLog(logList);
		return returnFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {

		return true;
	}

}
