package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanDtlToday implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{
		JXPathContext ctx = JXPathContext.newContext(context);
		Boolean resultFlag=true;
		  BigDecimal tempSum=new BigDecimal(0);
		
		List<String> logList = new ArrayList<>();
		
			BigDecimal loanMisId = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/LOANID", BigDecimal.class);
			
			BigDecimal loanTotlAccrdAmt = (BigDecimal) ctx.getValue("/loan_account/loan_mis_details/TOTAL_ACCRUED_AMT", BigDecimal.class);
			
			
			
			
		
			
	
		List<Map<?,?>> accuralDtl = MVEL.eval("loan_account.?accrual_details", context, List.class);
		
			
		if(accuralDtl!=null)
		{
			
			
			         Iterator<Map<?, ?>> it = accuralDtl.iterator();
			         while (it.hasNext())
			         {
				     Map<String,String> mapValues = (Map<String, String>) it.next();				
				
				     BigDecimal accrlDtlLoanId=new BigDecimal(0);
				     BigDecimal accrlDtlVapid=new BigDecimal(0);
				     BigDecimal accredAmt=new BigDecimal(0);
				     BigDecimal accrualId=new BigDecimal(0);
				    		
				       for (Map.Entry entries : mapValues.entrySet())
				            {
					           if(("LOANID").equals(entries.getKey()))
					           {
					        	   accrlDtlLoanId=(BigDecimal) entries.getValue();
						          
						       }
					           if(("VAPID").equals(entries.getKey()))
					           {
					        	   accrlDtlVapid=(BigDecimal) entries.getValue();
						          
						       }
					           if(("ACCRUEDAMT").equals(entries.getKey()))
					           {
					        	   accredAmt=(BigDecimal) entries.getValue();
						          
						       }
					           if(("ID").equals(entries.getKey()))
					           {
					        	   accrualId=(BigDecimal) entries.getValue();
						          
						       }
				            }
				       if((accrlDtlLoanId.compareTo(loanMisId)==0)&&(accrlDtlVapid.compareTo(BigDecimal.ZERO)==0))
				       {
				    	   
				       tempSum=tempSum.add(accredAmt);
				       
				       
				       }
				   
				       if(loanTotlAccrdAmt.compareTo(tempSum)==0)
				       {
				    	   //do nothing
				       }
				       else
				       {
				    	     logList.add("LMS_LOAN_ACCOUNT_DTL for whom there is a mismatch in Total_Accrued_Amt in loan Mis Table and  Sum of Accrued Amount in LMS_ACCRUAL_INCOME_DTL for Accrual Detail Id:"+accrualId);
				    		   resultFlag=false;
                    

				       }
				       }
			         if(resultFlag)
			         {
			        	 logList.add("There is no mismatch in Total_Accrued_Amt in loan Mis Table and  Sum of Accrued Amount in LMS_ACCRUAL_INCOME_DTL.");
			        	 
			        	 
			        	 
			         }
				       }
		else
		{
			logList.add("No record available in Accrual Detail.");
			resultFlag=false;
		
			
		}
				       
	      
				       logger.setLog(logList);
						return resultFlag;
						
	}

	@Override
	public boolean shouldExecute(RootObject context) 
	{
	
		return true;
	}

}
