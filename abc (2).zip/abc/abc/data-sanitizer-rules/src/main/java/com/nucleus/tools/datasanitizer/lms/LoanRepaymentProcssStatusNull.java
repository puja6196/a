package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanRepaymentProcssStatusNull implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		// TODO Auto-generated method stub

		             boolean returnFlag=true;
			
			         List<String> logList = new ArrayList<String>();
		
			         List<Map<?,?>> gradedDetails = MVEL.eval("loan_account.?graded_slab_details", context, List.class);
			
			        
			
			         if(gradedDetails!=null)
			               {
								
				              Iterator<Map<?, ?>> it = gradedDetails.iterator();
				              while (it.hasNext())
									
				                 {
					                  Map<String,String> mapValues = (Map<String, String>) it.next();
					
					                 String processStatus=null;
					
					                      for (Map.Entry entries : mapValues.entrySet())
					                            {
						                          if(("PROCESS_STATUS").equals(entries.getKey()))
						                                 {
							                                 processStatus=(String) entries.getValue();
							
						                                 }
							
					                            }
							                      if(processStatus!=null)
							                             {
								                             logList.add("Number of records where Process Status is not null");
								                             returnFlag=false;
								
							                             }
				                 }
							                      if(returnFlag)
							                      {
							                    	  
							                    	  
							                    	  logList.add("Number of records where Process Status is null");
							                    	  
							                    	  
							                      }
				   
			                     
					       
				
	                            }	
			         else
			         {
			        	 
			        	 logList.add("No record found in graded details.");
			        	 returnFlag=false;
			        	 
			         }
				
			       
			       
			            
			         logger.setLog(logList);
					return returnFlag;
			
	
     }

	@Override
	public boolean shouldExecute(RootObject context) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
