package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class TDS857 implements RuleExecutor 
{


	@Override
	public boolean execute(RootObject context, Logger logger)
	{
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<>();
		boolean resultFlag = true;
		BigDecimal tdsCurrentStatus = (BigDecimal) ctx.getValue("/loan_account/tds_details/CURRENT_STATUS", BigDecimal.class);
		Date tdsCertificateDate = (Date) ctx.getValue("/loan_account/tds_details/CERTIFICATE_DATE", Date.class);
		BigDecimal tdsCertificateNo = (BigDecimal) ctx.getValue("/loan_account/tds_details/CERTIFICATE_NUMBER", BigDecimal.class);
		BigDecimal tdsPaidAmt = (BigDecimal) ctx.getValue("/loan_account/tds_details/TDS_PAID_AMT", BigDecimal.class);
		
		if((tdsCurrentStatus.compareTo(new BigDecimal(515120))==0)&&((tdsCertificateDate==null)||(tdsCertificateNo==null)||((tdsPaidAmt.compareTo(BigDecimal.ZERO)==0)&&(tdsPaidAmt.compareTo(BigDecimal.ZERO)<1))))
		{
			logList.add("LMS_TDS_DTL  where CERTIFICATE_DATE is null or CERTIFICATE_NUMBER is null or TDS_PAID_AMT<=0 when CURRENT_STATUS is Acknowledged.");
			resultFlag=false;
		}		
		if(resultFlag)
		{
			
			logList.add("LMS_TDS_DTL  where CERTIFICATE_DATE is null or CERTIFICATE_NUMBER is null or TDS_PAID_AMT<=0 when CURRENT_STATUS is Acknowledged.");
			
		}
		
		
		logger.setLog(logList);
		return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

}
