package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAdvcLMSDtlWithAllctnMismtch implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		Boolean resultFlag=true;
		BigDecimal tempSum=new BigDecimal(0);
	      List<String> logList = new ArrayList<String>();
		  List<Map<?,?>> advcDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
   	  List<Map<?,?>> allctnDtls = MVEL.eval("loan_account.?allocation_details", context, List.class);
	 
   	if(advcDtl!=null)
    {
       Iterator<Map<?, ?>> it = advcDtl.iterator();
         while (it.hasNext())
          {
	          Map<String,String> mapValues = (Map<String, String>) it.next();				
	          BigDecimal advcAlloctdAmt=new BigDecimal(0);
	          BigDecimal advcId=new BigDecimal(0);
	         
	          String advDtlId=null;
	      
	    
	               for (Map.Entry entries : mapValues.entrySet())
	                  {
		                   if(("ALLOCATEDAMT").equals(entries.getKey()))
		                       {
		        	              advcAlloctdAmt=(BigDecimal) entries.getValue();
			          
			                   }
		                   if(("ID").equals(entries.getKey()))
	                       {
		                	   advcId=(BigDecimal) entries.getValue();
		          
		                   }
		                   Iterator<Map<?, ?>> itr = allctnDtls.iterator();
		                   while (it.hasNext())
		                    {
		          	          Map<String,String> mapValue = (Map<String, String>) it.next();				
		          	      
		          	        
		          	      BigDecimal alloctnAllctdAmt=new BigDecimal(0);
		          	      BigDecimal recvblePyblTranId=new BigDecimal(0);
		          	      String alloctnStatus=null;
		          	    
		          	               for (Map.Entry entrie : mapValue.entrySet())
		          	                  {
		          		                   if(("ALLOCATEDAMT").equals(entrie.getKey()))
		          		                       {
		          		                	 alloctnAllctdAmt=(BigDecimal) entrie.getValue();
		          			          
		          			                   }
		          		                 if(("RECEIVABLE_PAYABLE_TXN_ID").equals(entrie.getKey()))
	          		                       {
	          		                	 recvblePyblTranId=(BigDecimal) entrie.getValue();
	          			          
	          			                   }
		          		               if(("STATUS").equals(entrie.getKey()))
          		                       {
          		                	 alloctnStatus=(String) entrie.getValue().toString();
          			          
          			                   }
		          		                 
		          	                  }
		          	               if(alloctnStatus=="A")
		          	               {
		          	               if(recvblePyblTranId.compareTo(advcId)==0)
		          	               {
		          	            	   tempSum=tempSum.add(alloctnAllctdAmt);
		          	               
		          	               }
		          	               }
		          	               if(tempSum==null)
		          	               {
		          	            	   tempSum=BigDecimal.ZERO;
		          	               
		          	               }
		          	               }
		          	               }
		                    }
	                  }
	          		                   
		        	            
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject context) 
	{
		// TODO Auto-generated method stub
		return true;
	}

}
