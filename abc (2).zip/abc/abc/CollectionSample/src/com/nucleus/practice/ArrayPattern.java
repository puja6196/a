package com.nucleus.practice;

import java.util.Scanner;

public class ArrayPattern 
{
	public static void main(String args[])
	{
		int i;
		int arr[]={1,2,3,4,5,6};
		System.out.println("Enter the value of k");
		Scanner sc=new Scanner(System.in);
		int k=sc.nextInt();
		int arr1[]=new int[6];
		for(i=0;i<k;i++)
		{
			
		}
		for(i=k;i<6;i++)
		{
			if(i+k<6)
			{
			arr1[i]=arr[i+k];
			}
		}
	}

}
