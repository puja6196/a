package com.nucleus.practice;

import java.util.Scanner;

public class Fact {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a num");
		int num=sc.nextInt();
		int fac=1;
		for(int i=1;i<=num;i++)
		{
			fac=i*fac;
		}

		System.out.println(fac);
	}

}
