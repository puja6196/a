package com.nucleus.practice;

public class Pattern1 
{
	public static void main(String args[])
	{
		int i,j,k,i1,j1,k1;
		for(i1=0;i1<4;i1++)
		{
			System.out.println("");
			for(k1=0;k1<4-i1;k1++)
			{
				System.out.print(" ");
				
			}
			for(j1=0;j1<i1;j1++)
			{
				System.out.print("*");
				System.out.print(" ");
			}
		}
		for(i=0;i<=4;i++)
		{
			System.out.println("");
			for(j=0;j<i;j++)
			{
				System.out.print(" ");
			}
			for(k=0;k<4-i;k++)
			{
				System.out.print("*");
				System.out.print(" ");
			}
		}
		
	}

}
