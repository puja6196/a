package com.nucleus.practice;

import java.math.BigDecimal;

public class NestedIterator 
{
	public static void main(String []args)
	{
	BigDecimal a=new BigDecimal(0);
	BigDecimal b=new BigDecimal(0);
	if(a !=null){
		System.out.println("hello");
	}else{
		System.out.println("hii");
	}
	}

}
