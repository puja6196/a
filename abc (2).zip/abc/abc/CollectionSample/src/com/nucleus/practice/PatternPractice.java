package com.nucleus.practice;

public class PatternPractice 
{
	public static void main(String args[])
	{
		int j;
		for(int i=0;i<4;i++)
		{
			for(j=0;j<i;j++)
			{
				System.out.println(" ");			}
			for(int k=0;k<i-j;k++)
			{
				System.out.print("*");
				
			}
		}
	}

}
