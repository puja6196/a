package com.nucleus.practice;

public class Pattern2 {

	public static void main(String[] args) 
	{
		int i1,j1,k1;
	

	}

}
