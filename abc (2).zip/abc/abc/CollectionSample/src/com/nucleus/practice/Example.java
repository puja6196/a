package com.nucleus.practice;

import java.util.Scanner;

public class Example {

	public static void main(String[] args) {
//		String str="tripti";
//		String str2="tripti";
//		str2="tripti"+" "+"sharma";
//		String str4=str.concat("sharma").concat("alld");
//		String str1=new String("tripti");
//		
//		System.out.println(str==str1);
//		System.out.println(str==str2);
//		System.out.println(str2);
//		System.out.println(str4);
//
//		System.out.println(str2.substring(0,6));
//		System.out.println(str2.substring(0,6).toUpperCase());
//		System.out.println(str2.length());
		String orig;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		orig=sc.next();
		String temp="";
		for(int i=orig.length()-1;i>=0;i--)
		{
			temp=temp+orig.charAt(i);
		}
		if(temp.equals(orig))
		{
			System.out.println("no.is palindrome:"+orig);
		}
		else
		{
			System.out.println("no.is not palindrome");
		}
	}

}
